#!/bin/bash
# Double-click to start the Putt Map app. Close this window to stop it.
cd "$(dirname "$0")/putt-map-app" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python isn't installed. Get it from https://www.python.org/downloads/ , install it, then double-click this again."
  read -n 1 -s -r -p "Press any key to close."
  exit 1
fi
python3 start.py
echo
read -n 1 -s -r -p "The app has stopped. Press any key to close."
