"""
Golf ball roll physics on a measured green elevation grid.

Adapted from the putting physics in imran31415/putty (MIT License,
commit 26dd443), files src/components/PuttingCoach/PuttingPhysics.ts and
src/constants/puttingPhysics.ts. Kept from putty: the ball and hole
constants, the step-integrate-until-stopped loop, speed-gated hole capture,
the result fields (trajectory, roll distance, success, closest approach) and
the idea of a "recommended aim" helper.

Replaced, because putty only supports one uniform slope and uses tuned
game-feel multipliers: the force model now reads the local slope from an
elevation grid at every step, rolling resistance comes from the Stimpmeter
reading, and hole capture uses the free-fall-over-the-hole condition, which
reproduces the ~1.6 m/s maximum capture speed reported in the putting
literature. Wind and air drag were dropped (negligible at putting speeds).

Units: metres, seconds, m/s. Coordinates: x = grid columns, y = grid rows,
z = elevation. Row 0 of the grid is at y = origin_y.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

G = 9.81                      # m/s^2
BALL_RADIUS = 0.02135         # m (regulation 1.68 in diameter)
HOLE_RADIUS = 0.054           # m (regulation 4.25 in diameter)
BALL_DIAMETER = 2 * BALL_RADIUS
STIMP_RELEASE_SPEED = 1.83    # m/s, ball speed leaving a Stimpmeter ramp
ROLLING_FACTOR = 5.0 / 7.0    # solid sphere rolling without slipping
FEET = 0.3048


# --------------------------------------------------------------------------
# Elevation grid
# --------------------------------------------------------------------------

class ElevationGrid:
    """Regular grid of elevations, z[row, col], with bilinear sampling."""

    def __init__(self, z, spacing, origin=(0.0, 0.0)):
        z = np.asarray(z, dtype=float)
        if z.ndim != 2 or min(z.shape) < 2:
            raise ValueError("elevation grid must be a 2D array of at least 2x2")
        if np.isnan(z).any():
            raise ValueError("elevation grid contains NaN; fill gaps before simulating")
        self.z = z
        self.spacing = float(spacing)
        self.origin_x, self.origin_y = map(float, origin)
        self.rows, self.cols = z.shape
        dz_dy, dz_dx = np.gradient(z, self.spacing)
        self.dz_dx, self.dz_dy = dz_dx, dz_dy
        # Plain lists are much faster than numpy scalars in the step loop.
        self._z = z.tolist()
        self._gx = dz_dx.tolist()
        self._gy = dz_dy.tolist()

    @classmethod
    def from_csv(cls, path, spacing, origin=(0.0, 0.0), delimiter=","):
        return cls(np.loadtxt(path, delimiter=delimiter), spacing, origin)

    @classmethod
    def from_npy(cls, path, spacing, origin=(0.0, 0.0)):
        return cls(np.load(path), spacing, origin)

    @property
    def extent(self):
        """(xmin, xmax, ymin, ymax) in metres."""
        return (self.origin_x, self.origin_x + (self.cols - 1) * self.spacing,
                self.origin_y, self.origin_y + (self.rows - 1) * self.spacing)

    def contains(self, x, y):
        xmin, xmax, ymin, ymax = self.extent
        return xmin <= x <= xmax and ymin <= y <= ymax

    def _cell(self, x, y):
        fx = (x - self.origin_x) / self.spacing
        fy = (y - self.origin_y) / self.spacing
        c = min(max(int(fx), 0), self.cols - 2)
        r = min(max(int(fy), 0), self.rows - 2)
        return r, c, fx - c, fy - r

    @staticmethod
    def _bilinear(a, r, c, tx, ty):
        return ((a[r][c] * (1 - tx) + a[r][c + 1] * tx) * (1 - ty)
                + (a[r + 1][c] * (1 - tx) + a[r + 1][c + 1] * tx) * ty)

    def height(self, x, y):
        r, c, tx, ty = self._cell(x, y)
        return self._bilinear(self._z, r, c, tx, ty)

    def gradient_many(self, x, y):
        """Vectorised gradient for arrays of points (clamped to the grid)."""
        fx = (x - self.origin_x) / self.spacing
        fy = (y - self.origin_y) / self.spacing
        c = np.clip(fx.astype(int), 0, self.cols - 2)
        r = np.clip(fy.astype(int), 0, self.rows - 2)
        tx, ty = fx - c, fy - r
        out = []
        for a in (self.dz_dx, self.dz_dy):
            out.append((a[r, c] * (1 - tx) + a[r, c + 1] * tx) * (1 - ty)
                       + (a[r + 1, c] * (1 - tx) + a[r + 1, c + 1] * tx) * ty)
        return out[0], out[1]

    def gradient(self, x, y):
        """(dz/dx, dz/dy) at a point, i.e. rise per metre in x and y."""
        r, c, tx, ty = self._cell(x, y)
        return (self._bilinear(self._gx, r, c, tx, ty),
                self._bilinear(self._gy, r, c, tx, ty))


# --------------------------------------------------------------------------
# Simulation
# --------------------------------------------------------------------------

@dataclass
class GreenConditions:
    stimp_feet: float = 10.0          # Stimpmeter reading in feet
    hole_radius: float = HOLE_RADIUS
    ball_radius: float = BALL_RADIUS

    @property
    def rolling_deceleration(self):
        """Flat-green deceleration (m/s^2) implied by the Stimpmeter reading."""
        return STIMP_RELEASE_SPEED ** 2 / (2.0 * self.stimp_feet * FEET)


@dataclass
class PuttResult:
    holed: bool
    stopped: bool                     # came to rest on the green
    left_green: bool                  # rolled off the edge of the grid
    final_position: tuple
    trajectory: np.ndarray            # (N, 4): t, x, y, z
    speeds: np.ndarray                # (N,) speed at each trajectory point
    roll_distance: float              # path length in metres
    time: float                       # seconds until rest/holed/off
    closest_approach: float           # min distance from ball centre to hole centre
    speed_at_closest: float
    final_distance_to_hole: float
    notes: list = field(default_factory=list)


def simulate_putt(grid, start, hole, speed, aim_deg, conditions=None,
                  dt=0.002, max_time=30.0, capture=True, record_every=5):
    """Roll a ball from `start` with launch `speed` (m/s) and `aim_deg`.

    aim_deg is measured from the straight line start -> hole, positive to the
    left (counter-clockwise seen from above). Set capture=False to let the
    ball roll over the hole (used by the aim solver).
    """
    cond = conditions or GreenConditions()
    a_roll = cond.rolling_deceleration
    hx, hy = hole
    x, y = start
    base = math.atan2(hy - y, hx - x)
    heading = base + math.radians(aim_deg)
    vx, vy = speed * math.cos(heading), speed * math.sin(heading)

    # Ball is captured if it spends long enough over the hole to drop by its
    # own radius (Penner 2002 style criterion; ~1.64 m/s max for a centred putt).
    t_drop = math.sqrt(2.0 * cond.ball_radius / G)
    time_over_hole = 0.0

    t = 0.0
    path = [(t, x, y, grid.height(x, y))]
    speeds = [speed]
    dist = 0.0
    closest = math.hypot(x - hx, y - hy)
    speed_at_closest = speed
    holed = stopped = left = False
    step = 0

    while t < max_time:
        gx, gy = grid.gradient(x, y)
        norm = math.sqrt(1.0 + gx * gx + gy * gy)
        # Downhill pull along the surface, projected to the horizontal plane.
        ax = -ROLLING_FACTOR * G * gx / norm
        ay = -ROLLING_FACTOR * G * gy / norm
        v = math.hypot(vx, vy)

        if v < a_roll * dt:
            # Nearly stopped: stays put unless the slope beats rolling resistance.
            if math.hypot(ax, ay) <= a_roll:
                stopped = True
                break
            vx += ax * dt
            vy += ay * dt
        else:
            nvx = vx + (ax - a_roll * vx / v) * dt
            nvy = vy + (ay - a_roll * vy / v) * dt
            # Rolling resistance can stop the ball but never push it backwards.
            if nvx * vx + nvy * vy < 0 and math.hypot(ax, ay) <= a_roll:
                stopped = True
                break
            vx, vy = nvx, nvy

        nx, ny = x + vx * dt, y + vy * dt
        dist += math.hypot(nx - x, ny - y)
        x, y = nx, ny
        t += dt
        step += 1

        if not grid.contains(x, y):
            left = True
            path.append((t, x, y, float("nan")))
            speeds.append(math.hypot(vx, vy))
            break

        d = math.hypot(x - hx, y - hy)
        v = math.hypot(vx, vy)
        if d < closest:
            closest, speed_at_closest = d, v
        if capture:
            if d <= cond.hole_radius:
                time_over_hole += dt
                if time_over_hole >= t_drop or v < 0.05:
                    holed = True
                    path.append((t, x, y, grid.height(x, y)))
                    speeds.append(v)
                    break
            else:
                time_over_hole = 0.0   # lipped across without dropping

        if step % record_every == 0:
            path.append((t, x, y, grid.height(x, y)))
            speeds.append(v)

    if path[-1][0] != t:
        path.append((t, x, y, grid.height(x, y) if grid.contains(x, y) else float("nan")))
        speeds.append(math.hypot(vx, vy))

    notes = []
    if not (holed or stopped or left):
        notes.append(f"still rolling after max_time={max_time}s")
    return PuttResult(
        holed=holed, stopped=stopped, left_green=left,
        final_position=(x, y), trajectory=np.array(path), speeds=np.array(speeds),
        roll_distance=dist, time=t, closest_approach=closest,
        speed_at_closest=speed_at_closest,
        final_distance_to_hole=math.hypot(x - hx, y - hy), notes=notes,
    )


# --------------------------------------------------------------------------
# Aim solver ("read the putt")
# --------------------------------------------------------------------------

def _speed_for_pace(grid, start, hole, aim_deg, cond, entry_speed, dt):
    """Bisect launch speed so the ball passes the hole at `entry_speed`."""
    lo, hi = 0.05, 8.0
    for _ in range(22):
        mid = 0.5 * (lo + hi)
        r = simulate_putt(grid, start, hole, mid, aim_deg, cond, dt=dt,
                          capture=False, record_every=10_000)
        if r.speed_at_closest >= entry_speed:
            hi = mid
        else:
            lo = mid
    return hi


def recommend_putt(grid, start, hole, conditions=None, entry_speed=0.6,
                   aim_range=30.0, dt=0.004):
    """Find aim and launch speed that hole the putt with a firm-but-makeable pace.

    entry_speed: speed (m/s) the ball should have as it reaches the hole.
    ~0.6 m/s on a stimp-10 green means a miss would finish ~30 cm past.
    Returns (aim_deg, speed, PuttResult of the recommended putt).
    """
    cond = conditions or GreenConditions()

    def miss(aim):
        s = _speed_for_pace(grid, start, hole, aim, cond, entry_speed, dt)
        r = simulate_putt(grid, start, hole, s, aim, cond, dt=dt, capture=False,
                          record_every=10_000)
        return r.closest_approach, s

    # Coarse sweep, then golden-section refinement around the best angle.
    aims = np.linspace(-aim_range, aim_range, 25)
    scores = [miss(a)[0] for a in aims]
    i = int(np.argmin(scores))
    lo = aims[max(i - 1, 0)]
    hi = aims[min(i + 1, len(aims) - 1)]
    phi = (math.sqrt(5) - 1) / 2
    a, b = hi - phi * (hi - lo), lo + phi * (hi - lo)
    fa, fb = miss(a)[0], miss(b)[0]
    for _ in range(18):
        if fa < fb:
            hi, b, fb = b, a, fa
            a = hi - phi * (hi - lo)
            fa = miss(a)[0]
        else:
            lo, a, fa = a, b, fb
            b = lo + phi * (hi - lo)
            fb = miss(b)[0]
    aim = 0.5 * (lo + hi)
    _, speed = miss(aim)
    result = simulate_putt(grid, start, hole, speed, aim, cond)
    return aim, speed, result


# --------------------------------------------------------------------------
# Aim as golfers say it: "N balls outside the right edge"
# --------------------------------------------------------------------------

@dataclass
class AimPoint:
    aim_deg: float           # angle from the straight line, positive = left
    side: str                # "left", "right" or "centre"
    offset_m: float          # perpendicular distance of the aim point from the hole centre
    balls_from_centre: float
    balls_outside: float     # past the edge of the cup; negative = aim is inside the cup
    point: tuple             # (x, y) aim point beside the hole

    def __str__(self):
        if self.side == "centre" or self.balls_from_centre < 0.05:
            return "aim at the centre of the hole"
        if self.balls_outside >= 0.05:
            return f"aim {self.balls_outside:.1f} balls outside the {self.side} edge"
        if self.balls_outside > -0.05:
            return f"aim at the {self.side} edge"
        return f"aim {self.balls_from_centre:.1f} balls {self.side} of centre (inside the cup)"


def aim_point(start, hole, aim_deg, hole_radius=HOLE_RADIUS):
    """Convert an aim angle into the point beside the hole the golfer aims at.

    The aim point is where the aim line crosses the line through the hole
    centre perpendicular to the putt, measured in golf-ball widths (42.7 mm).
    """
    sx, sy = start
    hx, hy = hole
    d = math.hypot(hx - sx, hy - sy)
    offset = d * math.tan(math.radians(aim_deg))     # + = left
    ux, uy = (hx - sx) / d, (hy - sy) / d
    lx, ly = -uy, ux                                  # unit vector to the left
    side = "left" if offset > 0 else "right" if offset < 0 else "centre"
    off = abs(offset)
    return AimPoint(
        aim_deg=aim_deg, side=side, offset_m=off,
        balls_from_centre=off / BALL_DIAMETER,
        balls_outside=(off - hole_radius) / BALL_DIAMETER,
        point=(hx + lx * offset, hy + ly * offset),
    )


# --------------------------------------------------------------------------
# Batch solver: many putts to one hole at once (numpy, ~100x faster per putt)
# --------------------------------------------------------------------------

def _roll_batch(grid, x, y, vx, vy, hole, a_roll, dt, max_time):
    """Roll many balls (capture off). Returns closest approach and speed there."""
    hx, hy = hole
    n = len(x)
    closest = np.hypot(x - hx, y - hy)
    v_closest = np.hypot(vx, vy)
    idx = np.arange(n)
    x, y, vx, vy = x.copy(), y.copy(), vx.copy(), vy.copy()
    xmin, xmax, ymin, ymax = grid.extent
    t = 0.0
    while len(idx) and t < max_time:
        gx, gy = grid.gradient_many(x, y)
        norm = np.sqrt(1.0 + gx * gx + gy * gy)
        ax = -ROLLING_FACTOR * G * gx / norm
        ay = -ROLLING_FACTOR * G * gy / norm
        v = np.hypot(vx, vy)
        slope_a = np.hypot(ax, ay)
        safe_v = np.maximum(v, 1e-9)
        nvx = vx + (ax - a_roll * vx / safe_v) * dt
        nvy = vy + (ay - a_roll * vy / safe_v) * dt
        slow = v < a_roll * dt
        nvx = np.where(slow, vx + ax * dt, nvx)
        nvy = np.where(slow, vy + ay * dt, nvy)
        held = slope_a <= a_roll
        stopped = held & (slow | (nvx * vx + nvy * vy < 0))
        vx = np.where(stopped, 0.0, nvx)
        vy = np.where(stopped, 0.0, nvy)
        x = x + vx * dt
        y = y + vy * dt
        t += dt
        dxh, dyh = x - hx, y - hy
        d = np.hypot(dxh, dyh)
        sp = np.hypot(vx, vy)
        better = d < closest[idx]
        closest[idx] = np.where(better, d, closest[idx])
        v_closest[idx] = np.where(better, sp, v_closest[idx])
        off = (x < xmin) | (x > xmax) | (y < ymin) | (y > ymax)
        receding = (dxh * vx + dyh * vy > 0) & (d > closest[idx] + 0.3)
        done = stopped | off | receding
        if done.any():
            keep = ~done
            idx, x, y, vx, vy = idx[keep], x[keep], y[keep], vx[keep], vy[keep]
    return closest, v_closest


def _solve_batch(grid, sx, sy, aims, hole, cond, entry_speed, dt, max_time):
    """For each (start, aim) pair, bisect launch speed for the entry pace."""
    hx, hy = hole
    base = np.arctan2(hy - sy, hx - sx)
    head = base + np.radians(aims)
    cos_h, sin_h = np.cos(head), np.sin(head)
    a_roll = cond.rolling_deceleration
    lo = np.full(len(sx), 0.05)
    hi = np.full(len(sx), 6.0)
    for _ in range(18):
        mid = 0.5 * (lo + hi)
        _, vc = _roll_batch(grid, sx, sy, mid * cos_h, mid * sin_h, hole, a_roll, dt, max_time)
        fast = vc >= entry_speed
        hi = np.where(fast, mid, hi)
        lo = np.where(fast, lo, mid)
    miss, _ = _roll_batch(grid, sx, sy, hi * cos_h, hi * sin_h, hole, a_roll, dt, max_time)
    return miss, hi


def recommend_putts(grid, starts, hole, conditions=None, entry_speed=0.6,
                    aim_range=40.0, dt=0.004, max_time=15.0):
    """Batch version of recommend_putt for many starts and one hole.

    Returns arrays (aim_deg, speed, miss_m), one entry per start. miss_m is
    the closest approach of the recommended line to the hole centre; under
    HOLE_RADIUS means the line finds the cup.
    """
    cond = conditions or GreenConditions()
    starts = np.asarray(starts, dtype=float)
    n = len(starts)
    centre = np.zeros(n)
    passes = [(aim_range, 2.0), (2.0, 0.4), (0.4, 0.08), (0.08, 0.02)]
    for half, step in passes:
        offs = np.arange(-half, half + 1e-9, step)
        k = len(offs)
        aims = (centre[:, None] + offs[None, :]).ravel()
        sx = np.repeat(starts[:, 0], k)
        sy = np.repeat(starts[:, 1], k)
        miss, spd = _solve_batch(grid, sx, sy, aims, hole, cond, entry_speed, dt, max_time)
        miss = miss.reshape(n, k)
        best = np.argmin(miss, axis=1)
        centre = aims.reshape(n, k)[np.arange(n), best]
        best_miss = miss[np.arange(n), best]
        best_speed = spd.reshape(n, k)[np.arange(n), best]
    return centre, best_speed, best_miss


def load_grid(path, spacing, origin=(0.0, 0.0)):
    """Load an elevation grid from .csv or .npy."""
    p = Path(path)
    if p.suffix.lower() == ".npy":
        return ElevationGrid.from_npy(p, spacing, origin)
    return ElevationGrid.from_csv(p, spacing, origin)
