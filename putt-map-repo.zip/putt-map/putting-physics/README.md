# Putting physics for green elevation grids

A small Python module (numpy only) that rolls a golf ball across an elevation grid and tells you whether the putt drops, plus a solver that finds the aim and pace to hole it.

## Where it came from

Adapted from [imran31415/putty](https://github.com/imran31415/putty) (MIT License, commit `26dd443`), mainly `src/components/PuttingCoach/PuttingPhysics.ts` and `src/constants/puttingPhysics.ts`. MIT lets you reuse and modify the code as long as the copyright notice below stays with it.

putty's physics is built for a game: it assumes one uniform slope for the whole green and tunes ball behaviour with hand-picked multipliers. It cannot read terrain. So the module keeps putty's structure (ball and hole constants, the step loop, speed-gated hole capture, the result fields, a "recommended aim" helper) and replaces the force model with standard rolling-ball physics:

| Piece | putty | This module |
|---|---|---|
| Slope | one number for the whole green | local gradient of your grid at every step, bilinear |
| Green speed | ad-hoc multipliers | Stimpmeter reading sets rolling resistance (ball leaves the ramp at 1.83 m/s and must roll exactly the stimp distance on flat; verified for 8, 10, 12 ft) |
| Downhill pull | `sin(slope) * g` | `(5/7) g` along the fall line (a rolling solid ball) |
| Hole capture | within a radius and below a speed, tuned per distance band | ball must spend long enough over the hole to drop by its own radius; gives a max centred capture speed of about 1.64 m/s, matching the published ~1.63 m/s |
| Wind, air drag | included | dropped (negligible for putts) |

## Grid format

- 2D array `z[row, col]` in **metres**, saved as `.csv` (comma-separated, no header) or `.npy`.
- Columns run along **x**, rows along **y**; row 0 is at `y = origin_y`. Spacing is the same in both directions (e.g. 0.10 m).
- No NaNs; fill holes in the survey before simulating.

If the green-sheet pipeline writes row 0 as the top (north) of the image, pass `np.flipud(z)` or adjust coordinates accordingly.

## Use

```python
from putting_physics import load_grid, GreenConditions, simulate_putt, recommend_putt

grid = load_grid("green.csv", spacing=0.10)
cond = GreenConditions(stimp_feet=11)

r = simulate_putt(grid, start=(3.0, 1.0), hole=(3.2, 7.5), speed=2.9, aim_deg=-2.0, conditions=cond)
r.holed, r.final_position, r.trajectory   # trajectory columns: t, x, y, z

aim, speed, result = recommend_putt(grid, (3.0, 1.0), (3.2, 7.5), cond)
```

`aim_deg` is measured from the straight line to the hole, positive = left. To say it the way a golfer would, convert it to an aim point beside the hole, measured perpendicular to the putt line in golf-ball widths (42.7 mm):

```python
from putting_physics import aim_point
ap = aim_point(start, hole, aim)
print(ap)                 # "aim 3.2 balls outside the right edge"
ap.balls_outside, ap.balls_from_centre, ap.offset_m, ap.point
```

`balls_outside` counts from the edge of the cup (negative means the aim is inside the cup); `balls_from_centre` counts from the hole centre. `recommend_putt` targets a ball arriving at the hole at 0.6 m/s (change `entry_speed`).

## Demo

`python3 demo.py` builds a synthetic 6 m × 9 m green (2% cross-slope, 1.5% uphill, a 6 cm mound), saves it as `synthetic_green.csv`, loads it back, and plots `demo_putt.png`. Output:

```
Green 61x91 cells, stimp 10 ft, putt 6.50 m
Straight at hole @ 2.73 m/s: holed=False, finished 0.85 m from hole
Recommended: aim 3.2 balls outside the right edge (19 cm from centre, 1.7 deg) @ 2.99 m/s -> holed=True in 3.7 s, rolled 6.50 m
```

## Putt map (every putt around a pin)

```
python3 putt_map.py ../green-sheet-to-3d/output/my_sheet --out maps/my_sheet
```

Picks a pin (or use `--pin x,y`), solves every putt on a 1 ft grid within 10 ft (`--radius-ft`, `--spacing-ft`, `--stimp`), re-rolls each solved line to check it holes, and writes `putt_map.png` (whole green), `putt_map_zoom.png` (the circle) and `putt_map.csv`. Each spot shows only a number: balls outside the edge of the cup to aim, blue = left, red = right, black 0 = inside the cup. It uses `recommend_putts`, the batch solver, which takes about 0.15 s per putt instead of 9 to 17 s.

## Limits

- Ball always rolls without skidding (the first few centimetres after impact are skid in reality).
- Uniform green speed; no grain direction (putty's `greenGrain` field was never used either).
- Hole capture ignores lip-outs off the rim edge; it is a good first-order model, not a rim-contact simulation.

## putty license

```
MIT License

Copyright (c) 2025 Putty Golf Simulator

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
