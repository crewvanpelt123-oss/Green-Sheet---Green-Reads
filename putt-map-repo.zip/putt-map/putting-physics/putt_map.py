"""
Putt map: solve every putt within a radius of a pin and mark each spot with
its aim in golf balls outside the hole (blue = aim left, red = aim right).

    python3 putt_map.py ../green-sheet-to-3d/output/my_sheet --out maps/my_sheet
    python3 putt_map.py <green folder> --pin 11.2,19.5 --radius-ft 10 --spacing-ft 1 --stimp 11

<green folder> is a green-sheet-to-3d output folder (elevation.npy, green_mask.npy).
Without --pin, a pin is picked on the green: at least radius + 0.5 m from the
edge where possible, with a local slope as close to 2.5 % as available.
Writes putt_map.png (whole green), putt_map_zoom.png (the circle up close)
and putt_map.csv (every spot: position, aim in balls and degrees, speed, holed).
"""

import argparse
import csv
import json
import math
import time
from pathlib import Path

import numpy as np

import putting_physics as pp

FT = 0.3048
LEFT_COLOR = "#1f4fd1"
RIGHT_COLOR = "#d1261f"
CENTRE_COLOR = "#222222"


def edge_distance(mask, spacing):
    """Approximate distance (m) from each green cell to the edge, by erosion."""
    dist = np.zeros(mask.shape)
    cur = mask.copy()
    k = 0
    while cur.any():
        k += 1
        dist[cur] = k * spacing
        nxt = cur.copy()
        nxt[1:, :] &= cur[:-1, :]
        nxt[:-1, :] &= cur[1:, :]
        nxt[:, 1:] &= cur[:, :-1]
        nxt[:, :-1] &= cur[:, 1:]
        nxt[0, :] = nxt[-1, :] = False
        nxt[:, 0] = nxt[:, -1] = False
        cur = nxt
    return dist


def pick_pin(grid, mask, radius_m, target_slope=0.025):
    s = grid.spacing
    dist = edge_distance(mask, s)
    slope = np.hypot(grid.dz_dx, grid.dz_dy)
    # Average slope over ~1 m so the pin sits on a consistent plane.
    k = max(1, int(round(0.5 / s)))
    pad = np.pad(slope, k, mode="edge")
    avg = np.zeros_like(slope)
    for dr in range(-k, k + 1):
        for dc in range(-k, k + 1):
            avg += pad[k + dr:k + dr + slope.shape[0], k + dc:k + dc + slope.shape[1]]
    avg /= (2 * k + 1) ** 2
    for need in (radius_m + 0.5, radius_m * 0.6, 1.0):
        ok = mask & (dist >= need)
        if ok.any():
            break
    score = np.where(ok, np.abs(avg - target_slope), np.inf)
    r, c = np.unravel_index(np.argmin(score), score.shape)
    return (grid.origin_x + c * s, grid.origin_y + r * s), float(avg[r, c]), float(dist[r, c])


def spots_around(pin, radius_m, spacing_m, grid, mask, min_m):
    n = int(radius_m / spacing_m) + 1
    out = []
    for i in range(-n, n + 1):
        for j in range(-n, n + 1):
            x, y = pin[0] + i * spacing_m, pin[1] + j * spacing_m
            d = math.hypot(x - pin[0], y - pin[1])
            if d < min_m or d > radius_m + 1e-9 or not grid.contains(x, y):
                continue
            c = int(round((x - grid.origin_x) / grid.spacing))
            r = int(round((y - grid.origin_y) / grid.spacing))
            if mask[r, c]:
                out.append((x, y))
    return np.array(out)


def label_for(ap):
    if ap.balls_outside < 0.05:
        return "0", CENTRE_COLOR          # aim inside the cup
    return f"{ap.balls_outside:.1f}", (LEFT_COLOR if ap.side == "left" else RIGHT_COLOR)


def draw(path, grid, mask, pin, radius_m, rows, title, zoom, font_pt, radius_ft=10):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle

    s = grid.spacing
    xs = grid.origin_x + np.arange(grid.cols) * s
    ys = grid.origin_y + np.arange(grid.rows) * s
    rr, cc = np.nonzero(mask)
    if zoom:
        pad = 0.6
        x0, x1 = pin[0] - radius_m - pad, pin[0] + radius_m + pad
        y0, y1 = pin[1] - radius_m - pad, pin[1] + radius_m + pad
        width_in = 11
    else:
        pad = 1.0
        x0, x1 = xs[cc.min()] - pad, xs[cc.max()] + pad
        y0, y1 = ys[rr.min()] - pad, ys[rr.max()] + pad
        width_in = 14
    h_in = width_in * (y1 - y0) / (x1 - x0) + 0.9
    fig, ax = plt.subplots(figsize=(width_in, h_in))

    z = np.where(mask, grid.z, np.nan)
    zc = z - np.nanmean(z)
    ax.imshow(zc, origin="lower", extent=(xs[0] - s / 2, xs[-1] + s / 2, ys[0] - s / 2, ys[-1] + s / 2),
              cmap="Greens", alpha=0.55, interpolation="bilinear")
    levels = np.arange(np.floor(np.nanmin(zc) / 0.02) * 0.02, np.nanmax(zc) + 0.02, 0.02)
    ax.contour(xs, ys, zc, levels=levels, colors="#2d5a2d", linewidths=0.35, alpha=0.5)
    ax.contour(xs, ys, mask.astype(float), levels=[0.5], colors="#1b3d1b", linewidths=1.2)

    ax.add_patch(Circle(pin, radius_m, fill=False, ls="--", lw=1.0, color="#333333"))
    ax.add_patch(Circle(pin, pp.HOLE_RADIUS * (3 if not zoom else 1.5), color="black", zorder=5))
    for x, y, txt, col in rows:
        ax.text(x, y, txt, color=col, fontsize=font_pt, ha="center", va="center",
                fontweight="bold", zorder=6)

    ax.set_xlim(x0, x1)
    ax.set_ylim(y0, y1)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_title(title, fontsize=11, loc="left")
    fig.text(0.01, 0.005,
             "Number = balls outside the edge of the cup to aim.   "
             "Blue = aim left   Red = aim right   Black 0 = aim inside the cup.   "
             f"Dashed circle = {radius_ft:g} ft.   Up = top of the sheet.   Contours every 2 cm.",
             fontsize=8, color="#333333")
    fig.tight_layout(rect=(0, 0.02, 1, 1))
    fig.savefig(path, dpi=220)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("green", help="green-sheet-to-3d output folder")
    ap.add_argument("--out", required=True)
    ap.add_argument("--pin", help="x,y in metres (grid coordinates)")
    ap.add_argument("--radius-ft", type=float, default=10.0)
    ap.add_argument("--spacing-ft", type=float, default=1.0)
    ap.add_argument("--min-ft", type=float, default=1.0, help="skip putts shorter than this")
    ap.add_argument("--stimp", type=float, default=11.0)
    ap.add_argument("--entry-speed", type=float, default=0.6)
    a = ap.parse_args()

    gdir, out = Path(a.green), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    meta = json.loads((gdir / "meta.json").read_text()) if (gdir / "meta.json").exists() else {}
    spacing = meta.get("spacing_m", 0.10)
    grid = pp.load_grid(gdir / "elevation.npy", spacing)
    mask = np.load(gdir / "green_mask.npy")
    cond = pp.GreenConditions(stimp_feet=a.stimp)
    radius = a.radius_ft * FT

    if a.pin:
        pin = tuple(float(v) for v in a.pin.split(","))
        pin_note = "given"
    else:
        pin, pslope, pdist = pick_pin(grid, mask, radius)
        pin_note = f"auto: {pslope * 100:.1f}% slope, {pdist:.1f} m from the edge"
    print(f"pin at ({pin[0]:.2f}, {pin[1]:.2f}) m [{pin_note}]")

    spots = spots_around(pin, radius, a.spacing_ft * FT, grid, mask, a.min_ft * FT)
    print(f"{len(spots)} putts to solve")
    t = time.time()
    aims, speeds, misses = pp.recommend_putts(grid, spots, pin, cond, entry_speed=a.entry_speed)
    t_solve = time.time() - t
    print(f"solved in {t_solve:.0f} s")

    rows, holed = [], 0
    with open(out / "putt_map.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["x_m", "y_m", "distance_ft", "aim_side", "aim_balls_outside",
                    "aim_balls_from_centre", "aim_deg", "speed_mps", "holed"])
        for (x, y), aim, spd in zip(spots, aims, speeds):
            res = pp.simulate_putt(grid, (x, y), pin, spd, aim, cond)
            holed += res.holed
            apt = pp.aim_point((x, y), pin, aim)
            txt, col = label_for(apt)
            rows.append((x, y, txt, col))
            w.writerow([f"{x:.3f}", f"{y:.3f}", f"{math.dist((x, y), pin) / FT:.1f}",
                        apt.side if apt.balls_outside >= 0.05 else "inside",
                        f"{apt.balls_outside:.2f}", f"{apt.balls_from_centre:.2f}",
                        f"{aim:.2f}", f"{spd:.3f}", int(res.holed)])
    print(f"check: {holed}/{len(spots)} solved lines hole when re-rolled")

    name = meta.get("source_image", gdir.name)
    title = (f"{name}: aim for every putt within {a.radius_ft:g} ft "
             f"(stimp {a.stimp:g}, {a.spacing_ft:g} ft spacing)")
    draw(out / "putt_map.png", grid, mask, pin, radius, rows, title, zoom=False, font_pt=4.2, radius_ft=a.radius_ft)
    draw(out / "putt_map_zoom.png", grid, mask, pin, radius, rows, title, zoom=True, font_pt=8, radius_ft=a.radius_ft)
    (out / "putt_map.json").write_text(json.dumps(dict(
        pin_m=[round(pin[0], 3), round(pin[1], 3)], pin_choice=pin_note, stimp=a.stimp,
        radius_ft=a.radius_ft, spacing_ft=a.spacing_ft, putts=len(spots), holed_on_check=holed,
        solve_seconds=round(t_solve, 1)), indent=2))
    print(f"wrote {out}/putt_map.png, putt_map_zoom.png, putt_map.csv")


if __name__ == "__main__":
    main()
