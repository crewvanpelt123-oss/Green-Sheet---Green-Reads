"""
Demo: a putt on a synthetic 6 m x 9 m green at 10 cm spacing.

The green tilts 2% right-to-left, 1.5% uphill toward the hole, and has a
gentle mound between ball and hole. It is written to CSV and read back, so
the same code path works for a grid produced from a green sheet.

Run:  python3 demo.py        (matplotlib optional, for demo_putt.png)
"""

import math
from pathlib import Path

import numpy as np

from putting_physics import GreenConditions, aim_point, load_grid, recommend_putt, simulate_putt

HERE = Path(__file__).parent
SPACING = 0.10  # metres

# --- build and save a synthetic green -------------------------------------
xs = np.arange(0, 6.0 + 1e-9, SPACING)
ys = np.arange(0, 9.0 + 1e-9, SPACING)
X, Y = np.meshgrid(xs, ys)                                # rows = y, cols = x
z = 0.02 * X + 0.015 * Y                                  # tilt: rises to the right and uphill
z += 0.06 * np.exp(-((X - 2.6) ** 2 + (Y - 4.5) ** 2) / (2 * 0.8 ** 2))  # mound
csv_path = HERE / "synthetic_green.csv"
np.savetxt(csv_path, z, delimiter=",", fmt="%.4f")

# --- load it back the way a real green would be loaded ---------------------
grid = load_grid(csv_path, spacing=SPACING)
cond = GreenConditions(stimp_feet=10)
start, hole = (3.0, 1.0), (3.2, 7.5)
dist = math.dist(start, hole)
print(f"Green {grid.cols}x{grid.rows} cells, stimp {cond.stimp_feet} ft, putt {dist:.2f} m")

# 1) Naive putt: straight at the hole with flat-green pace.
naive_speed = math.sqrt(2 * cond.rolling_deceleration * (dist + 0.3))
naive = simulate_putt(grid, start, hole, naive_speed, 0.0, cond)
print(f"Straight at hole @ {naive_speed:.2f} m/s: holed={naive.holed}, "
      f"finished {naive.final_distance_to_hole:.2f} m from hole")

# 2) Solver: find the aim and pace that hole it.
aim, speed, best = recommend_putt(grid, start, hole, cond)
ap = aim_point(start, hole, aim)
print(f"Recommended: {ap} ({ap.offset_m * 100:.0f} cm from centre, {abs(aim):.1f} deg) "
      f"@ {speed:.2f} m/s -> holed={best.holed} in {best.time:.1f} s, rolled {best.roll_distance:.2f} m")

# --- picture ---------------------------------------------------------------
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:
    print("matplotlib not installed; skipping demo_putt.png")
else:
    fig, ax = plt.subplots(figsize=(5, 7))
    cs = ax.contourf(X, Y, z * 100, levels=20, cmap="Greens")
    ax.contour(X, Y, z * 100, levels=20, colors="k", linewidths=0.3, alpha=0.4)
    fig.colorbar(cs, ax=ax, label="elevation (cm)")
    ax.plot(naive.trajectory[:, 1], naive.trajectory[:, 2], "--", color="tab:red",
            label="straight at hole")
    ax.plot(best.trajectory[:, 1], best.trajectory[:, 2], color="tab:blue",
            label=str(ap))
    ax.plot([start[0], ap.point[0]], [start[1], ap.point[1]], ":", color="tab:blue", lw=0.8)
    ax.plot(*ap.point, "x", color="tab:blue")
    ax.add_patch(plt.Circle(hole, 0.054 * 2, color="k"))
    ax.plot(*start, "o", color="white", mec="k")
    ax.set_aspect("equal"); ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
    ax.legend(loc="lower right", fontsize=8)
    ax.set_title("Putt on synthetic green (hole drawn 2x size)")
    fig.tight_layout()
    fig.savefig(HERE / "demo_putt.png", dpi=130)
    print("wrote demo_putt.png")
