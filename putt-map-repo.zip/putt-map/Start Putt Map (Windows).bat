@echo off
rem Double-click to start the Putt Map app. Close this window to stop it.
cd /d "%~dp0putt-map-app"
where py >nul 2>nul && (py -3 start.py & goto done)
where python >nul 2>nul && (python start.py & goto done)
echo Python is not installed. Get it from https://www.python.org/downloads/ and tick "Add python.exe to PATH" during install, then double-click this again.
:done
echo.
pause
