# Green sheet → 3D green model

Turns a green sheet image (slope arrows + slope % numbers) into an elevation grid and a 3D mesh that the putting physics module in `../putting-physics` can roll a ball on.

```
python3 green3d.py my_sheet.png --out output/my_sheet
```

Needs `numpy scipy opencv-python-headless matplotlib`. It takes about 30 seconds per sheet.

## How it works

1. **Read the sheet** (`sheet_reader.py`).
   - **Scale:** the grid squares are found from the spacing of the thin grid lines. One square is one yard by default (`--grid-yards`).
   - **Arrows:** found with an oriented matched filter on the coloured pixels. The filter checks a straight shaft with a head at one end at 72 angles and keeps the best fit. Each arrow points downhill.
   - **Numbers:** read with a small template OCR, then matched to the arrow just left of each number. The digit templates (`digit_templates.npz`) are not in this repo, because they were cut from ProGreenBook sheets; build your own from one labelled sheet of yours. Without them, arrow-and-number sheets can't be read (StrackaLine sheets don't need them).
   - **Arrows with no number** (mostly off the green): the slope is estimated from the arrow's colour (yellow = gentle, purple = steep). The colour-to-slope curve is fitted on that same sheet's numbered arrows.
2. **Rebuild the surface** (`surface.py`). The tool solves for the smoothest surface whose slope matches every arrow, as a sparse least-squares problem with a thin-plate smoothness penalty. Each arrow constrains the slope along its own length. Arrows that disagree strongly with their neighbours are down-weighted. An arrow that comes out pointing backwards (a misread arrowhead) is flipped and the surface is solved again.
3. **Export** (`green3d.py`): grid, mesh, green outline mask, preview images, and a putt roll test.

## Outputs (`--out` folder)

| File | What it is |
|---|---|
| `elevation.npy` / `.csv` | Heights in **metres**, 0.10 m spacing, **row 0 = bottom edge of the sheet**, columns left to right, no gaps. Mean green height = 0. This is the putting-physics grid format; load with `load_grid(path, spacing=0.10)`. |
| `green_mask.npy` | True inside the green's outline (same shape as the grid). |
| `mesh.obj` | Triangle mesh, metres, Z up, covering the whole grid. |
| `meta.json` | Size, scale, height range, fit quality, roll test result. |
| `arrows.csv` | Every arrow that was read: position, downhill direction (`dir_deg`, 0 = right, 90 = up the sheet), `slope_pct`, and `source` (number / colour / +flipped). |
| `review.png` | The sheet with what was read drawn on top. Blue = numbered arrow, green = colour-estimated, **red = flagged** (disagrees with the rebuilt surface). The label is the arrow's id in `arrows.csv`. |
| `relief.png` | Shaded relief with 1 cm contours on the green, and a plot of read slope vs rebuilt slope. |
| `roll_test.png` | A ~6 m putt across the slope, aimed straight vs at the recommended line (stimp 11 by default). The aim is given in golf balls outside the edge of the hole, measured perpendicular to the putt line, and marked with an x. |

## Fixing misreads

Open `review.png`, find the red or wrong arrows by id, and edit `arrows.csv`. You can change `dir_deg` or `slope_pct`, set `use` to 0 to drop an arrow, or add a row (only `x_m, y_m, dir_deg, slope_pct` are needed). Then run:

```
python3 green3d.py my_sheet.png --out output/my_sheet_fixed --arrows output/my_sheet/arrows.csv
```

## Photos

Flat scans and screenshots work as they are. For a photo taken at an angle, pass the pixel corners of any rectangle on the page in this order: top-left, top-right, bottom-right, bottom-left. The grid's outer corners work well. For example:

```
python3 green3d.py photo.jpg --out output/hole3 --corners 210,330,1890,295,1950,2700,160,2740
```

## Accuracy on a ProGreenBook sheet (Pebble Beach 8, not included in this repo for copyright reasons)

| Measure | Result |
|---|---|
| Arrows read | 284, of which 115 have their number read |
| Rebuilt surface vs the sheet's numbers | median 0.2 % slope, 1° direction |
| Held-out check (20 % of numbered arrows hidden, then predicted) | median 0.6 % slope, 6° direction |
| Green | about 1.0 m of fall front to back, median slope 5.2 % (the sheet's numbers average about 5 %) |

## Known limits

- Slopes off the green come from arrow colour, so they are rougher (about ±1.5 %) than on the green. Putting only uses the green, where most arrows have numbers.
- About a third of the numbers on this sheet are missed: some digits touch arrows or grid lines. The rebuilt surface still uses those arrows, with the colour-based estimate for their slope.
- The digit templates come from ProGreenBook sheets. Another publisher's font may need new templates (rebuild them from one labelled sheet).
- Low-resolution images (like this 1138 × 1775 example) are at the limit. A sharper photo will read more arrows correctly.
- "Up" in the output is the top of the sheet, not compass north.
