"""Rebuild an elevation surface from slope arrows.

Every arrow says "at this point the ground falls s% in this direction", i.e.
it fixes the gradient of the surface there. We look for the smoothest surface
on a regular grid whose gradient matches the arrows:

    minimise  sum_arrows w_i |grad z(p_i) - g_i|^2  +  lam * sum |second differences of z|^2

That is a sparse linear least-squares problem. Arrows that disagree strongly
with their neighbours (a misread direction, say) are down-weighted with a
few rounds of Huber re-weighting, and reported so they can be checked.
"""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


def arrow_gradients(tab):
    """Gradient (dz/dx, dz/dy) of each arrow; arrows point downhill."""
    a = np.deg2rad(tab['dir_deg'])
    s = tab['slope_pct'] / 100.0
    return -s * np.cos(a), -s * np.sin(a)


def _bilinear_grad_rows(px, py, x0, y0, h, nx, ny):
    """Sparse rows giving dz/dx and dz/dy at points (px, py) from the grid,
    using the gradient of the bilinear interpolant of the containing cell."""
    fx = (px - x0) / h
    fy = (py - y0) / h
    j = np.clip(np.floor(fx).astype(int), 0, nx - 2)
    i = np.clip(np.floor(fy).astype(int), 0, ny - 2)
    tx = np.clip(fx - j, 0, 1)
    ty = np.clip(fy - i, 0, 1)
    idx = lambda ii, jj: ii * nx + jj
    n = len(px)
    r = np.arange(n)
    # z = (1-tx)(1-ty) z00 + tx(1-ty) z01 + (1-tx)ty z10 + tx ty z11
    cols = np.stack([idx(i, j), idx(i, j + 1), idx(i + 1, j), idx(i + 1, j + 1)], 1)
    wx = np.stack([-(1 - ty), (1 - ty), -ty, ty], 1) / h
    wy = np.stack([-(1 - tx), -tx, (1 - tx), tx], 1) / h
    Gx = sp.csr_matrix((wx.ravel(), (np.repeat(r, 4), cols.ravel())), shape=(n, nx * ny))
    Gy = sp.csr_matrix((wy.ravel(), (np.repeat(r, 4), cols.ravel())), shape=(n, nx * ny))
    return Gx, Gy


def _second_diff(nx, ny, h):
    """Thin-plate smoothness: d2/dx2, d2/dy2 and sqrt(2) d2/dxdy."""
    def D2(n):
        return sp.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n)) / h ** 2
    def D1(n):
        return sp.diags([-1.0, 1.0], [0, 1], shape=(n - 1, n)) / h
    Ix, Iy = sp.identity(nx), sp.identity(ny)
    Dxx = sp.kron(Iy, D2(nx))
    Dyy = sp.kron(D2(ny), Ix)
    Dxy = sp.kron(D1(ny), D1(nx)) * np.sqrt(2)
    return sp.vstack([Dxx, Dyy, Dxy]).tocsr()


def reconstruct(tab, spacing=0.10, margin=1.0, lam=0.05, huber=0.015, iters=4,
                extent=None, arrow_len=0.75, samples=5):
    """Return dict with z (ny, nx) in metres (row 0 = bottom of the sheet),
    x0, y0, spacing, and per-arrow fit diagnostics.

    lam    : smoothness weight (bigger = smoother, less faithful)
    huber  : gradient error (as a fraction, 0.015 = 1.5%) above which an
             arrow is progressively down-weighted
    extent : (xmin, ymin, xmax, ymax) in metres; default = arrows + margin
    """
    px, py = np.asarray(tab['x_m'], float), np.asarray(tab['y_m'], float)
    gx, gy = arrow_gradients(tab)
    if extent is None:
        extent = (px.min() - margin, py.min() - margin, px.max() + margin, py.max() + margin)
    xmin, ymin, xmax, ymax = extent
    nx = int(np.ceil((xmax - xmin) / spacing)) + 1
    ny = int(np.ceil((ymax - ymin) / spacing)) + 1
    # An arrow describes the slope along its own length (about 3/4 yard), so
    # its constraint is spread over a few points along the shaft.
    a = np.deg2rad(np.asarray(tab['dir_deg'], float))
    offs = np.linspace(-0.5, 0.5, samples) * arrow_len
    sx = (px[:, None] + np.cos(a)[:, None] * offs).ravel()
    sy = (py[:, None] + np.sin(a)[:, None] * offs).ravel()
    Sx, Sy = _bilinear_grad_rows(sx, sy, xmin, ymin, spacing, nx, ny)
    avg = sp.kron(sp.identity(len(px)), np.ones((1, samples)) / samples).tocsr()
    Gx, Gy = (avg @ Sx).tocsr(), (avg @ Sy).tocsr()
    S = _second_diff(nx, ny, spacing)
    # gauge: pin one corner (heights are shifted to mean 0 afterwards)
    Z = sp.csr_matrix(([1.0], ([0], [0])), shape=(1, nx * ny))

    # Smoothness is scaled per unit area so lam does not depend on spacing;
    # data terms are per arrow.
    area = spacing ** 2
    w = np.ones(len(px))
    if 'source' in tab:
        # numbers are read exactly; colour-estimated slopes are rougher
        w = np.where(np.char.startswith(np.asarray(tab['source']).astype(str), 'number'), 1.0, 0.5)
    w0 = w.copy()
    for it in range(iters):
        W = sp.diags(np.sqrt(w))
        A = sp.vstack([W @ Gx, W @ Gy, np.sqrt(lam * area) * S, Z]).tocsr()
        b = np.concatenate([np.sqrt(w) * gx, np.sqrt(w) * gy, np.zeros(S.shape[0]), [0.0]])
        AtA = (A.T @ A).tocsc()
        Atb = A.T @ b
        z = spla.spsolve(AtA, Atb)
        rx, ry = Gx @ z - gx, Gy @ z - gy
        r = np.hypot(rx, ry)
        # Huber weights
        w = w0 * np.where(r <= huber, 1.0, huber / np.maximum(r, 1e-12))
    z = z - z.mean()
    zg = z.reshape(ny, nx)
    fgx, fgy = Gx @ z, Gy @ z
    fit_slope = 100 * np.hypot(fgx, fgy)
    fit_dir = np.degrees(np.arctan2(-fgy, -fgx)) % 360
    ang_err = (fit_dir - np.asarray(tab['dir_deg']) + 180) % 360 - 180
    return dict(z=zg, x0=xmin, y0=ymin, spacing=spacing, nx=nx, ny=ny,
                fit_slope=fit_slope, fit_dir=fit_dir,
                slope_err=fit_slope - np.asarray(tab['slope_pct']),
                dir_err=ang_err, resid=100 * r, weight=w / w0)


def slope_map(z, spacing):
    gy, gx = np.gradient(z, spacing)
    return 100 * np.hypot(gx, gy), gx, gy


def write_obj(path, z, x0, y0, spacing, mask=None):
    """Triangle mesh, metres, Z up. Cells outside `mask` are left out."""
    ny, nx = z.shape
    with open(path, 'w') as fh:
        fh.write('# green surface from green-sheet-to-3d; units: metres, Z up\n')
        for i in range(ny):
            y = y0 + i * spacing
            for j in range(nx):
                fh.write(f'v {x0 + j * spacing:.3f} {y:.3f} {z[i, j]:.4f}\n')
        for i in range(ny - 1):
            for j in range(nx - 1):
                if mask is not None and not (mask[i, j] or mask[i + 1, j + 1]):
                    continue
                a = i * nx + j + 1
                b, c, d = a + 1, a + nx, a + nx + 1
                fh.write(f'f {a} {b} {d}\nf {a} {d} {c}\n')
