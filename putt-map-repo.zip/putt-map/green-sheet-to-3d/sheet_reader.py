"""Read a green sheet image into a table of slope arrows.

Each arrow on a green sheet points downhill; the number printed beside it is
the slope in percent. This module finds the arrows (direction from an oriented
matched filter), reads the numbers (small template OCR), pairs them up, and
estimates the slope of arrows that have no number from their colour, using a
colour-to-slope curve fitted on the arrows that do.

Output rows are in sheet pixels and in metres (x to the right of the sheet,
y towards the top of the sheet).
"""
import csv
import os

import cv2
import numpy as np

YARD_M = 0.9144
HERE = os.path.dirname(os.path.abspath(__file__))


# --------------------------------------------------------------------------
# Loading and rectifying
# --------------------------------------------------------------------------

def load_image(path, corners=None):
    """Load the sheet. `corners` = 4 (x, y) points (top-left, top-right,
    bottom-right, bottom-left) of any rectangle on the page, for photos taken
    at an angle; the image is warped so that rectangle is square-on."""
    im = cv2.imread(path)
    if im is None:
        raise FileNotFoundError(path)
    if corners is not None:
        src = np.float32(corners)
        w = int(max(np.linalg.norm(src[1] - src[0]), np.linalg.norm(src[2] - src[3])))
        h = int(max(np.linalg.norm(src[3] - src[0]), np.linalg.norm(src[2] - src[1])))
        dst = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
        M = cv2.getPerspectiveTransform(src, dst)
        im = cv2.warpPerspective(im, M, (w, h), borderValue=(255, 255, 255))
    # Small images (screenshots, scans like the example) are upscaled so the
    # thin arrows survive the filters; the scale factor is undone in metres.
    return im


# --------------------------------------------------------------------------
# Grid pitch (pixels per yard)
# --------------------------------------------------------------------------

def _line_profile(gray, axis):
    g = gray.astype(np.float32)
    if axis == 0:   # horizontal lines -> profile over rows
        r = (np.roll(g, 2, 0) + np.roll(g, -2, 0)) / 2 - g
        return (r > 20).sum(1).astype(np.float32)
    r = (np.roll(g, 2, 1) + np.roll(g, -2, 1)) / 2 - g
    return (r > 20).sum(0).astype(np.float32)


def _pitch_from_profile(p, lo=15, hi=90):
    p = p - p.mean()
    ac = np.correlate(p, p, 'full')[len(p) - 1:]
    lag = lo + int(np.argmax(ac[lo:hi]))
    # parabolic refinement
    a, b, c = ac[lag - 1], ac[lag], ac[lag + 1]
    return lag + 0.5 * (a - c) / (a - 2 * b + c + 1e-9)


def grid_pitch(im):
    """Pixels between grid lines, from the autocorrelation of thin-line
    responses in the middle of the sheet."""
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    H, W = gray.shape
    mid = gray[int(H * 0.25):int(H * 0.75), int(W * 0.15):int(W * 0.85)]
    py = _pitch_from_profile(_line_profile(mid, 0))
    px = _pitch_from_profile(_line_profile(mid, 1))
    return float((px + py) / 2), float(px), float(py)


# --------------------------------------------------------------------------
# Colour layers
# --------------------------------------------------------------------------

def layers(im):
    f = im.astype(np.float32)
    C = f.max(2) - f.min(2)                       # chroma
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    H = hsv[..., 0].astype(int)
    V = hsv[..., 2].astype(int)
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)

    green = (H >= 38) & (H <= 140) & (C > 40)     # green fringe outline
    sand = ((C > 30) & (C < 75) & (V > 225) & (H >= 10) & (H <= 25)).astype(np.uint8)
    sand = cv2.morphologyEx(sand, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    dark = ((gray < 120) & (C < 25)).astype(np.uint8)

    # arrow evidence: coloured, not green, not sand, not black text
    A = np.clip((C - 20) / 80, 0, 1)
    A[(H >= 38) & (H <= 140)] = 0
    A[cv2.dilate(sand, np.ones((9, 9), np.uint8)) > 0] = 0
    A[cv2.dilate(dark, np.ones((3, 3), np.uint8)) > 0] = 0
    # long coloured horizontal bands (page header/footer bars)
    for r in np.where((A > 0.3).mean(1) > 0.4)[0]:
        A[max(0, r - 6):r + 7] = 0
    return dict(A=A.astype(np.float32), C=C, H=H, V=V, gray=gray,
                green=green, sand=sand > 0)


# --------------------------------------------------------------------------
# Arrows
# --------------------------------------------------------------------------

def _arrow_kernel(theta, L, size):
    sc = 8  # sub-pixel drawing
    k = np.zeros((size, size), np.float32)
    c = size // 2
    u = np.array([np.cos(theta), np.sin(theta)])
    tip, tail = c + u * L / 2, c - u * L / 2
    P = lambda p: (int(round(p[0] * sc)), int(round(p[1] * sc)))
    cv2.line(k, P(tail), P(tip), 1.0, 1, cv2.LINE_AA, 3)
    wing = max(4.0, 0.22 * L)
    for s in (1, -1):
        a = theta + np.pi + s * 0.45
        cv2.line(k, P(tip), P(tip + wing * np.array([np.cos(a), np.sin(a)])),
                 1.0, 2, cv2.LINE_AA, 3)
    return k / k.sum()


def _support(Ad, x, y, theta, L, n=11):
    u = np.array([np.cos(theta), np.sin(theta)])
    pts = [(x + u[0] * s, y + u[1] * s) for s in np.linspace(-0.45, 0.45, n) * L]
    h, w = Ad.shape
    return np.mean([Ad[min(h - 1, max(0, int(round(py)))), min(w - 1, max(0, int(round(px))))] > 0.15
                    for px, py in pts])


def find_arrows(L_img, pitch, step_deg=5, thresh=0.25, min_support=0.8):
    """Oriented matched filter over the arrow-evidence map. Returns arrays of
    centre x, y (px), downhill direction angle (image radians) and score."""
    A = L_img['A']
    Larr = 0.85 * pitch
    size = int(Larr * 1.3) | 1
    angs = np.deg2rad(np.arange(0, 360, step_deg))
    R = np.stack([cv2.filter2D(A, -1, _arrow_kernel(a, Larr, size)) for a in angs])
    best, bi = R.max(0), R.argmax(0)
    mx = cv2.dilate(best, np.ones((5, 5), np.uint8))
    cy, cx = np.where((best == mx) & (best > thresh))
    Ad = cv2.dilate(A, np.ones((3, 3), np.uint8))
    sup = np.array([_support(Ad, x, y, angs[bi[y, x]], Larr) for x, y in zip(cx, cy)])
    keep = sup >= min_support
    cx, cy = cx[keep], cy[keep]
    order = np.argsort(-best[cy, cx])
    sel = []
    min_d = 0.75 * pitch
    for i in order:
        p = (cx[i], cy[i])
        if all((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 > min_d ** 2 for q in sel):
            sel.append(p)
    sel = np.array(sel, float).reshape(-1, 2)
    xs, ys = sel[:, 0].astype(int), sel[:, 1].astype(int)
    theta = angs[bi[ys, xs]]
    # head confidence: response vs the same line pointing the other way
    opp = (bi[ys, xs] + len(angs) // 2) % len(angs)
    head_conf = best[ys, xs] - R[opp, ys, xs]
    return dict(x=sel[:, 0], y=sel[:, 1], theta=theta, score=best[ys, xs],
                head_conf=head_conf, length=Larr)


def arrow_hue(im, L_img, arrows, pitch):
    """Unwrapped hue of each arrow's most saturated pixels:
    yellow ~ +30, orange ~ +15, red ~ 0, magenta ~ -15, purple ~ -30."""
    H, C, A = L_img['H'], L_img['C'], L_img['A']
    out = []
    r = int(0.3 * pitch)
    for x, y, t in zip(arrows['x'], arrows['y'], arrows['theta']):
        u = np.array([np.cos(t), np.sin(t)])
        hs = []
        for s in np.linspace(-0.4, 0.4, 9) * arrows['length']:
            px, py = int(round(x + u[0] * s)), int(round(y + u[1] * s))
            y0, y1, x0, x1 = max(0, py - 2), py + 3, max(0, px - 2), px + 3
            m = A[y0:y1, x0:x1] > 0.2
            if m.any():
                hh = H[y0:y1, x0:x1][m]
                cc = C[y0:y1, x0:x1][m]
                hs.append(hh[np.argmax(cc)])
        if not hs:
            out.append(np.nan)
            continue
        hs = np.array(hs)
        hs = np.where(hs > 90, hs - 180, hs)
        out.append(float(np.median(hs)))
    return np.array(out)


# --------------------------------------------------------------------------
# Numbers (slope %) via template OCR
# --------------------------------------------------------------------------

def _glyph_vec(gray, x, y, w, h):
    g = 255 - gray[y:y + h, x:x + w].astype(np.float32)
    return cv2.resize(g, (10, 14), interpolation=cv2.INTER_AREA).ravel() / 255


def read_numbers(im, L_img, pitch, templates=os.path.join(HERE, 'digit_templates.npz'),
                 max_dist=7.0):
    """Find 'd.d' labels. Glyph sizes scale with the grid pitch (the example
    sheet has ~37 px per yard and ~11 px tall digits)."""
    gray, C = L_img['gray'], L_img['C']
    if not os.path.exists(templates):
        raise FileNotFoundError(
            'Arrow-and-number sheets need digit_templates.npz next to sheet_reader.py '
            '(digit shapes cut from a labelled sheet of the same publisher). '
            'It is not included in this repository.')
    T = np.load(templates)
    TX, TY = T['X'], T['Y']
    s = pitch / 36.75
    t = ((gray < 140) & (C < 70)).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(t, 8)
    hs, ws, ar = st[:, 3], st[:, 2], st[:, 4]
    cand = [i for i in range(1, n)
            if 8 * s <= hs[i] <= 14 * s and 2 * s <= ws[i] <= 11 * s and ar[i] >= 10 * s * s]
    numbers = []
    used = set()
    cand_sorted = sorted(cand, key=lambda i: st[i, 0])
    for i in cand_sorted:
        if i in used:
            continue
        x, y, w, h, _ = st[i]
        best = None
        for j in cand_sorted:
            if j == i or j in used:
                continue
            x2, y2, w2, h2, _ = st[j]
            gap = x2 - (x + w)
            if 1 <= gap <= 14 * s and abs((y + h) - (y2 + h2)) <= 3 * s:
                if best is None or gap < best[0]:
                    best = (gap, j)
        if best is None:
            continue
        j = best[1]
        digits, dists = [], []
        for k in (i, j):
            v = _glyph_vec(gray, *st[k][:4])
            d = ((TX - v) ** 2).sum(1)
            digits.append(int(TY[d.argmin()]))
            dists.append(float(d.min()))
        if max(dists) > max_dist:
            continue
        used.update((i, j))
        x2, y2, w2, h2, _ = st[j]
        numbers.append(dict(value=digits[0] + digits[1] / 10,
                            left=float(x), cy=float(y + h / 2),
                            box=(int(x), int(min(y, y2)), int(x2 + w2 - x), int(max(h, h2))),
                            ocr_dist=max(dists)))
    return numbers


def pair_numbers(arrows, numbers, pitch, max_d=0.5):
    """Each label sits just right of its arrow's shaft. Greedy unique pairing
    by distance from the label's left-middle point to the arrow segment."""
    n = len(arrows['x'])
    val = np.full(n, np.nan)
    lab_idx = np.full(n, -1)
    L = arrows['length']
    cands = []
    for ai in range(n):
        u = np.array([np.cos(arrows['theta'][ai]), np.sin(arrows['theta'][ai])])
        c = np.array([arrows['x'][ai], arrows['y'][ai]])
        a, b = c - u * L / 2, c + u * L / 2
        for ni, num in enumerate(numbers):
            p = np.array([num['left'], num['cy']])
            t = np.clip(np.dot(p - a, b - a) / np.dot(b - a, b - a), 0, 1)
            d = np.linalg.norm(p - (a + t * (b - a)))
            if d < max_d * pitch:
                cands.append((d, ai, ni))
    taken_a, taken_n = set(), set()
    for d, ai, ni in sorted(cands):
        if ai in taken_a or ni in taken_n:
            continue
        taken_a.add(ai)
        taken_n.add(ni)
        val[ai] = numbers[ni]['value']
        lab_idx[ai] = ni
    return val, lab_idx


def fit_colour_curve(hue, slope):
    """Monotone (in hue) slope curve from labelled arrows: binned medians,
    made monotone decreasing (yellow = gentle, purple = steep), then
    linear interpolation with flat extrapolation plus a gentle linear tail."""
    ok = np.isfinite(hue) & np.isfinite(slope)
    h, s = hue[ok], slope[ok]
    if len(h) < 8:
        return None
    edges = np.unique(np.percentile(h, np.linspace(0, 100, 9)))
    xs, ys = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (h >= lo) & (h <= hi)
        if m.sum() >= 3:
            xs.append(np.median(h[m]))
            ys.append(np.median(s[m]))
    xs, ys = np.array(xs), np.array(ys)
    o = np.argsort(xs)
    xs, ys = xs[o], ys[o]
    # enforce monotone decreasing with hue (pool adjacent violators)
    ys = list(ys)
    w = [1.0] * len(ys)
    i = 0
    while i < len(ys) - 1:
        if ys[i] < ys[i + 1]:
            ys[i] = (ys[i] * w[i] + ys[i + 1] * w[i + 1]) / (w[i] + w[i + 1])
            w[i] += w[i + 1]
            del ys[i + 1], w[i + 1]
            xs = np.delete(xs, i + 1)
            i = max(i - 1, 0)
        else:
            i += 1
    xs, ys = np.array(xs), np.array(ys)
    slope_lo = (ys[0] - ys[-1]) / max(xs[-1] - xs[0], 1e-6)  # %/hue unit
    def f(hq):
        hq = np.asarray(hq, float)
        y = np.interp(hq, xs, ys)
        y = np.where(hq < xs[0], ys[0] + slope_lo * (xs[0] - hq), y)
        return np.clip(y, 0.2, 15.0)
    f.knots = (xs.tolist(), ys.tolist())
    return f


# --------------------------------------------------------------------------
# Driver
# --------------------------------------------------------------------------

def read_sheet(path, corners=None, grid_yards=1.0, region=None):
    """Return (arrows table as dict of arrays, info dict, image)."""
    im = load_image(path, corners)
    scale = 1.0
    pitch, px, py = grid_pitch(im)
    if pitch < 30:   # upscale low-resolution sheets
        scale = 36.75 / pitch
        im = cv2.resize(im, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        pitch, px, py = grid_pitch(im)
    L_img = layers(im)
    if region is not None:
        x0, y0, x1, y1 = region
        keep = np.zeros_like(L_img['A'])
        keep[y0:y1, x0:x1] = 1
        L_img['A'] *= keep
    arrows = find_arrows(L_img, pitch)
    hue = arrow_hue(im, L_img, arrows, pitch)
    numbers = read_numbers(im, L_img, pitch)
    val, lab_idx = pair_numbers(arrows, numbers, pitch)
    curve = fit_colour_curve(hue, val)
    slope = val.copy()
    source = np.where(np.isfinite(val), 'number', 'colour').astype(object)
    if curve is not None:
        miss = ~np.isfinite(slope)
        slope[miss] = curve(hue[miss])
    m_per_px = grid_yards * YARD_M / pitch
    H = im.shape[0]
    tab = dict(
        x_px=arrows['x'], y_px=arrows['y'],
        x_m=arrows['x'] * m_per_px, y_m=(H - arrows['y']) * m_per_px,
        # downhill direction in sheet coordinates (degrees, 0 = right, 90 = up)
        dir_deg=np.degrees(np.arctan2(-np.sin(arrows['theta']), np.cos(arrows['theta']))) % 360,
        slope_pct=slope, source=source, hue=hue,
        score=arrows['score'], head_conf=arrows['head_conf'],
    )
    info = dict(pitch_px=pitch, pitch_x_px=px, pitch_y_px=py, upscale=scale,
                m_per_px=m_per_px, image_h=H, image_w=im.shape[1],
                n_arrows=len(arrows['x']), n_numbers=len(numbers),
                n_paired=int(np.isfinite(val).sum()),
                colour_curve=curve.knots if curve is not None else None,
                arrow_length_px=arrows['length'], numbers=numbers)
    return tab, info, im, L_img


COLUMNS = ['x_px', 'y_px', 'x_m', 'y_m', 'dir_deg', 'slope_pct', 'source',
           'hue', 'score', 'head_conf']


def write_arrows_csv(tab, path):
    with open(path, 'w', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['id'] + COLUMNS + ['use'])
        for i in range(len(tab['x_px'])):
            row = [i]
            for c in COLUMNS:
                v = tab[c][i]
                row.append(f'{v:.3f}' if isinstance(v, (float, np.floating)) else v)
            row.append(1)
            w.writerow(row)


def read_arrows_csv(path):
    """Read a (possibly hand-edited) arrows CSV. Rows with use=0 are dropped.
    Edit dir_deg / slope_pct to fix a misread arrow; add a row to add one
    (x_m, y_m, dir_deg, slope_pct are the only columns needed)."""
    rows = list(csv.DictReader(open(path)))
    rows = [r for r in rows if r.get('use', '1').strip() not in ('0', 'no', 'false')]
    g = lambda k: np.array([float(r[k]) for r in rows])
    return dict(x_m=g('x_m'), y_m=g('y_m'), dir_deg=g('dir_deg'),
                slope_pct=g('slope_pct'),
                source=np.array([r.get('source', 'manual') for r in rows], object))
