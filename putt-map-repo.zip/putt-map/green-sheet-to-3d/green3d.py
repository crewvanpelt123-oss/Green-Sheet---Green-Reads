#!/usr/bin/env python3
"""Green sheet image -> 3D elevation grid + mesh for putting physics.

    python3 green3d.py my_sheet.png --out output/my_sheet

Writes to --out:
    arrows.csv         every arrow read from the sheet (edit and re-run with --arrows)
    review.png         the sheet with what was read drawn on top
    elevation.csv/.npy heights in metres, row 0 = bottom edge of the sheet,
                       even spacing (putting-physics grid format, origin (0, 0))
    green_mask.npy     True inside the green's outline
    mesh.obj           triangle mesh in metres, Z up
    meta.json          spacing, scale, fit quality
    relief.png         shaded relief + 1 cm contours + fit check
    roll_test.png      a putt simulated on the surface (needs ../putting-physics)
"""
import argparse
import json
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sheet_reader as sr  # noqa: E402
import surface as su       # noqa: E402


def green_mask_px(L_img):
    """Pixels inside the green's (green-coloured) outline."""
    g = L_img['green'].astype(np.uint8)
    # the outline is dashed: close the gaps, then fill everything it encloses
    n, lab, st, _ = cv2.connectedComponentsWithStats(g, 8)
    g = np.isin(lab, 1 + np.where(st[1:, 4] >= 20)[0]).astype(np.uint8)
    g0 = g
    # widen the closing until the outline encloses something
    for ks in (15, 25, 35, 45, 61, 81):
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ks, ks))
        g = cv2.morphologyEx(g0, cv2.MORPH_CLOSE, k)
        n, lab, st, _ = cv2.connectedComponentsWithStats(g, 8)
        if n < 2:
            return np.zeros(g.shape, bool)
        big = 1 + int(np.argmax(st[1:, 4]))
        ring = (lab == big).astype(np.uint8)
        outside = ring.copy()
        ff = np.zeros((g.shape[0] + 2, g.shape[1] + 2), np.uint8)
        cv2.floodFill(outside, ff, (0, 0), 1)
        inside = outside == 0
        if inside.sum() > 4 * ring.sum():
            return inside | (ring > 0)
    return np.zeros(g.shape, bool)


def draw_review(im, tab, info, path):
    out = im.copy()
    Lr = info['arrow_length_px'] / 2
    for i in range(len(tab['x_px'])):
        x, y = tab['x_px'][i], tab['y_px'][i]
        a = np.deg2rad(tab['dir_deg'][i])
        u = np.array([np.cos(a), -np.sin(a)])
        p0 = (int(x - u[0] * Lr), int(y - u[1] * Lr))
        p1 = (int(x + u[0] * Lr), int(y + u[1] * Lr))
        num = str(tab['source'][i]).startswith('number')
        col = (200, 60, 0) if num else (0, 150, 0)
        flagged = 'flag' in tab and tab['flag'][i]
        if flagged:
            col = (0, 0, 255)
        cv2.arrowedLine(out, p0, p1, col, 1, tipLength=0.3)
        cv2.putText(out, str(i), (int(x) - 12, int(y) + 4), cv2.FONT_HERSHEY_PLAIN, 0.7, col, 1)
    f = 2400 / max(out.shape[:2])
    cv2.imwrite(path, cv2.resize(out, None, fx=f, fy=f, interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_CUBIC))


def mask_to_grid(mask_px, info, r):
    """Resample a sheet-pixel mask onto the elevation grid."""
    ny, nx = r['z'].shape
    xs = r['x0'] + np.arange(nx) * r['spacing']
    ys = r['y0'] + np.arange(ny) * r['spacing']
    X, Y = np.meshgrid(xs, ys)
    u = np.round(X / info['m_per_px']).astype(int)
    v = np.round(info['image_h'] - Y / info['m_per_px']).astype(int)
    ok = (u >= 0) & (u < mask_px.shape[1]) & (v >= 0) & (v < mask_px.shape[0])
    out = np.zeros((ny, nx), bool)
    out[ok] = mask_px[v[ok], u[ok]]
    return out


def plot_relief(r, gmask, tab, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import LightSource
    z, h = r['z'], r['spacing']
    ny, nx = z.shape
    ext = (0, (nx - 1) * h, 0, (ny - 1) * h)
    fig, axs = plt.subplots(1, 2, figsize=(13, 8.5))
    ls = LightSource(azdeg=315, altdeg=35)
    zc = z * 100
    rgb = ls.shade(zc, cmap=plt.cm.terrain, vert_exag=12, dx=h * 100, dy=h * 100, blend_mode='soft')
    ax = axs[0]
    ax.imshow(rgb, origin='lower', extent=ext)
    lv = np.arange(np.floor(zc.min()), np.ceil(zc.max()) + 1, 1.0)
    zin = np.where(gmask, zc, np.nan)
    ax.contour(np.linspace(0, ext[1], nx), np.linspace(0, ext[3], ny), zin, levels=lv,
               colors='k', linewidths=0.4, alpha=0.6)
    ax.contour(np.linspace(0, ext[1], nx), np.linspace(0, ext[3], ny), gmask.astype(float),
               levels=[0.5], colors='g', linewidths=1.5)
    ax.set_title('Elevation (shaded, 1 cm contours on the green)\nrange %.2f m' % (z.max() - z.min()))
    ax.set_xlabel('x (m)')
    ax.set_ylabel('y (m), 0 = bottom of sheet')
    ax.set_aspect('equal')

    ax = axs[1]
    num = np.char.startswith(np.asarray(tab['source']).astype(str), 'number')
    ax.scatter(tab['slope_pct'][num], r['fit_slope'][num], s=12, label='numbered arrows')
    ax.scatter(tab['slope_pct'][~num], r['fit_slope'][~num], s=8, alpha=0.5,
               label='colour-estimated arrows')
    m = max(np.max(tab['slope_pct']), np.max(r['fit_slope'])) + 0.5
    ax.plot([0, m], [0, m], 'k--', lw=0.8)
    ax.set_xlabel('slope read from sheet (%)')
    ax.set_ylabel('slope of rebuilt surface (%)')
    ax.set_title('Fit check')
    ax.legend()
    ax.set_aspect('equal')
    fig.tight_layout()
    fig.savefig(path, dpi=110)
    plt.close(fig)


def roll_test(out_dir, r, gmask, stimp=11.0):
    """Simulate a putt across the green with the putting-physics module."""
    pp_dir = os.path.join(os.path.dirname(HERE), 'putting-physics')
    if not os.path.isdir(pp_dir):
        return None
    sys.path.insert(0, pp_dir)
    import putting_physics as pp
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    h = r['spacing']
    grid = pp.load_grid(os.path.join(out_dir, 'elevation.npy'), spacing=h)
    cond = pp.GreenConditions(stimp_feet=stimp)
    # Hole near the middle of the green, ball ~6 m away across the slope.
    ii, jj = np.where(gmask)
    cy, cx = ii.mean() * h, jj.mean() * h
    pts = np.c_[jj * h, ii * h]
    hole = pts[np.argmin(np.hypot(pts[:, 0] - cx, pts[:, 1] - cy))]
    best = None
    for ang in np.deg2rad(np.arange(0, 360, 15)):
        s = hole + 6.0 * np.array([np.cos(ang), np.sin(ang)])
        j, i = int(round(s[0] / h)), int(round(s[1] / h))
        if 0 <= i < gmask.shape[0] and 0 <= j < gmask.shape[1] and gmask[i, j]:
            # prefer the start with the most side-slope (biggest break)
            gy, gx = np.gradient(r['z'], h)
            d = (hole - s) / np.linalg.norm(hole - s)
            side = abs(-d[1] * gx[i, j] + d[0] * gy[i, j])
            if best is None or side > best[0]:
                best = (side, s)
    if best is None:
        return None
    start = best[1]
    aim, speed, res = pp.recommend_putt(grid, tuple(start), tuple(hole), cond)
    straight = pp.simulate_putt(grid, tuple(start), tuple(hole), speed, 0.0, cond)
    ap = pp.aim_point(tuple(start), tuple(hole), aim)

    z = r['z']
    ny, nx = z.shape
    fig, ax = plt.subplots(figsize=(7, 8))
    zin = np.where(gmask, z * 100, np.nan)
    im = ax.imshow(zin, origin='lower', extent=(0, (nx - 1) * h, 0, (ny - 1) * h), cmap='terrain')
    ax.contour(np.linspace(0, (nx - 1) * h, nx), np.linspace(0, (ny - 1) * h, ny), zin,
               levels=np.arange(np.nanmin(zin) // 1, np.nanmax(zin) + 1, 1.0),
               colors='k', linewidths=0.3, alpha=0.5)
    ax.plot(straight.trajectory[:, 1], straight.trajectory[:, 2], 'r--', lw=1.2,
            label='aimed straight: %s' % ('holed' if straight.holed else 'missed'))
    ax.plot(res.trajectory[:, 1], res.trajectory[:, 2], 'b-', lw=2,
            label='%s: %s' % (ap, 'holed' if res.holed else 'missed'))
    ax.plot([start[0], ap.point[0]], [start[1], ap.point[1]], 'b:', lw=0.8)
    ax.plot(*ap.point, 'bx', ms=7)
    ax.plot(*start, 'wo', mec='k')
    ax.plot(*hole, 'ko', ms=8)
    ax.legend(loc='upper left', fontsize=8)
    ax.set_title('Roll test on rebuilt green (stimp %.0f)' % stimp)
    ax.set_xlabel('x (m)')
    ax.set_ylabel('y (m)')
    fig.colorbar(im, ax=ax, shrink=0.6, label='height (cm)')
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, 'roll_test.png'), dpi=110)
    plt.close(fig)
    return dict(start=[round(float(v), 2) for v in start], hole=[round(float(v), 2) for v in hole],
                aim=str(ap), aim_balls_outside=round(ap.balls_outside, 1), aim_side=ap.side,
                aim_deg=round(float(aim), 2), speed=round(float(speed), 3), holed=bool(res.holed),
                straight_holed=bool(straight.holed), stimp=stimp)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('image')
    ap.add_argument('--out', required=True)
    ap.add_argument('--arrows', help='use this (edited) arrows.csv instead of reading arrows from the image')
    ap.add_argument('--corners', help='x1,y1,x2,y2,x3,y3,x4,y4: TL,TR,BR,BL of a rectangle on the page, for angled photos')
    ap.add_argument('--grid-yards', type=float, default=1.0, help='size of one grid square in yards (default 1)')
    ap.add_argument('--spacing', type=float, default=0.10, help='output grid spacing in metres (default 0.10)')
    ap.add_argument('--smooth', type=float, default=0.05, help='smoothness weight (default 0.05)')
    ap.add_argument('--stimp', type=float, default=11.0)
    a = ap.parse_args(argv)
    os.makedirs(a.out, exist_ok=True)
    corners = None
    if a.corners:
        v = [float(t) for t in a.corners.split(',')]
        corners = list(zip(v[0::2], v[1::2]))

    tab, info, im, L_img = sr.read_sheet(a.image, corners=corners, grid_yards=a.grid_yards)
    if a.arrows:
        tab = sr.read_arrows_csv(a.arrows)
    else:
        sr.write_arrows_csv(tab, os.path.join(a.out, 'arrows.csv'))
    print(f"grid pitch {info['pitch_px']:.1f} px/square, {len(tab['x_m'])} arrows, "
          f"{int(np.sum(np.char.startswith(np.asarray(tab['source']).astype(str), 'number')))} with numbers")

    r = su.reconstruct(tab, spacing=a.spacing, lam=a.smooth)
    # Arrowheads are tiny; an arrow whose read direction is backwards
    # relative to the surface its neighbours imply is flipped and re-solved.
    flip = np.abs(r['dir_err']) > 135
    if flip.any() and not a.arrows:
        tab = dict(tab)
        tab['dir_deg'] = np.where(flip, (tab['dir_deg'] + 180) % 360, tab['dir_deg'])
        tab['source'] = np.where(flip, np.char.add(np.asarray(tab['source']).astype(str), '+flipped'),
                                 np.asarray(tab['source']).astype(str)).astype(object)
        print(f'flipped {int(flip.sum())} arrows that pointed against their neighbours')
        r = su.reconstruct(tab, spacing=a.spacing, lam=a.smooth)
        sr.write_arrows_csv(tab, os.path.join(a.out, 'arrows.csv'))
    # Shift the grid so its bottom-left corner is (0, 0).
    x0, y0 = r['x0'], r['y0']
    z = r['z']
    gmask = mask_to_grid(green_mask_px(L_img), info, r)
    z_out = z - (z[gmask].mean() if gmask.any() else 0)   # mean green height = 0
    r['z'] = z_out
    np.save(os.path.join(a.out, 'elevation.npy'), z_out)
    np.savetxt(os.path.join(a.out, 'elevation.csv'), z_out, delimiter=',', fmt='%.5f')
    np.save(os.path.join(a.out, 'green_mask.npy'), gmask)
    su.write_obj(os.path.join(a.out, 'mesh.obj'), z_out, 0.0, 0.0, a.spacing)

    flag = (np.abs(r['slope_err']) > 1.0) | (np.abs(r['dir_err']) > 25) | (r['weight'] < 0.5)
    tab = dict(tab)
    tab['flag'] = flag
    if not a.arrows:
        draw_review(im, tab, info, os.path.join(a.out, 'review.png'))
    plot_relief(r, gmask, tab, os.path.join(a.out, 'relief.png'))

    num = np.char.startswith(np.asarray(tab['source']).astype(str), 'number')
    slope_in, _, _ = su.slope_map(z_out, a.spacing)
    meta = dict(
        source_image=os.path.basename(a.image),
        grid_format='heights in metres; row 0 = bottom edge of the sheet; columns run left to right; '
                    'origin (0, 0) at the bottom-left cell; even spacing',
        spacing_m=a.spacing, rows=int(z_out.shape[0]), cols=int(z_out.shape[1]),
        size_m=[round((z_out.shape[1] - 1) * a.spacing, 2), round((z_out.shape[0] - 1) * a.spacing, 2)],
        sheet_origin_m=[round(x0, 3), round(y0, 3)],
        sheet_px_per_grid_square=round(info['pitch_px'], 2), grid_square_yards=a.grid_yards,
        image_upscale=info['upscale'],
        height_range_m=round(float(z_out.max() - z_out.min()), 3),
        green_height_range_m=round(float(np.ptp(z_out[gmask])), 3) if gmask.any() else None,
        green_slope_pct=dict(median=round(float(np.median(slope_in[gmask])), 2),
                             max=round(float(slope_in[gmask].max()), 2)) if gmask.any() else None,
        arrows=int(len(tab['x_m'])), arrows_with_numbers=int(num.sum()),
        fit=dict(numbered_slope_err_median_pct=round(float(np.median(np.abs(r['slope_err'][num]))), 3),
                 numbered_dir_err_median_deg=round(float(np.median(np.abs(r['dir_err'][num]))), 2),
                 flagged_arrows=[int(i) for i in np.where(flag)[0]]),
        colour_curve=info['colour_curve'], smoothness=a.smooth,
    )
    rt = roll_test(a.out, r, gmask, a.stimp)
    if rt:
        meta['roll_test'] = rt
    json.dump(meta, open(os.path.join(a.out, 'meta.json'), 'w'), indent=2)
    print(json.dumps({k: meta[k] for k in ('size_m', 'height_range_m', 'green_height_range_m',
                                          'green_slope_pct', 'fit')}, indent=1))
    if rt:
        print('roll test:', rt)


if __name__ == '__main__':
    main()
