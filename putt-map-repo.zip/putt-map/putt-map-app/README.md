# Putt map app

A page in your browser where you load a green sheet photo, click the pin, enter the Stimpmeter reading, and get the aim for every putt within 10 feet.

## Start it

See the README at the top of this repository for the Mac and Windows start steps.

You can also keep this folder next to `green-sheet-to-3d` and `putting-physics`, open Terminal in this folder and run:

```
python3 start.py
```

Your browser opens at http://127.0.0.1:8765. If this Python is missing the libraries it needs (numpy, scipy, opencv, matplotlib), the first start installs them into a private `.venv` folder here, which takes a few minutes and needs internet. Press Ctrl+C in Terminal to stop. On Windows, use `python start.py`.

## Use it

1. **Green.** Pick a green you already read, or choose a new green sheet photo and press *Read this green sheet* (about 30 seconds). The links under the green show what was read, so you can check the arrows.
2. **Pin.** Click on the green to place the pin. The dashed circle shows the 10 ft radius. You can also type the pin as yards on from the front (bottom of the sheet) and yards in from the left edge of the green.
3. **Green speed.** Enter the Stimpmeter reading in feet. Radius and spacing default to 10 ft and 1 ft.
4. Press *Make the putt map* (about a minute). The page shows the close up and the whole green, with downloads for both pictures and the CSV of every putt.

Each number is how many balls outside the edge of the cup to aim: blue = left, red = right, black 0 = inside the cup.

Everything is saved under `data/` (greens you read, your photos, and each map in its own folder named by stimp and pin).

## Which sheets it reads

- **Arrow-and-number sheets** (like ProGreenBook): slope arrows with slope % numbers on a 1-yard grid. Read by `green-sheet-to-3d/green3d.py`.
- **StrackaLine sheets**: the stacked drawings with coloured slope bands (0-1 ... 9+) and the Low-High green elevation bar. Read by `strackaline.py`: the shape comes from the elevation colours, the steepness from the slope bands, and the scale from the 1-yard grid. On Southern Hills 18 the rebuilt green matches the sheet's printed slope numbers to a median of 0.7 %.

`read_sheet.py` picks the right reader. If a sheet can't be read, the page says why in plain words (the technical details are tucked under a link).

## Advanced

- *Grid square size*: for sheets whose grid isn't 1 yard.
- *Corners*: for a photo taken at an angle, the pixel corners of a rectangle on the page (top-left, top-right, bottom-right, bottom-left).

The app only runs `green-sheet-to-3d/green3d.py` and `putting-physics/putt_map.py`; it doesn't change them.
