#!/usr/bin/env python3
"""Putt map app: green sheet photo + Stimpmeter + pin -> aim map for every putt
within 10 ft.

    python3 start.py

Opens http://127.0.0.1:8765 in your browser. The first run installs the
Python libraries it needs. Keep this folder next to green-sheet-to-3d/ and
putting-physics/ (the app runs their commands; it does not change them).
Press Ctrl+C in the terminal to stop.
"""

import importlib
import tempfile
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
GREEN_TOOL = ROOT / "green-sheet-to-3d" / "green3d.py"
SHEET_READER = HERE / "read_sheet.py"
GREEN_EXAMPLES = ROOT / "green-sheet-to-3d" / "output"
PUTT_TOOL = ROOT / "putting-physics" / "putt_map.py"
DATA = HERE / "data"
GREENS = DATA / "greens"
MAPS = DATA / "maps"
UPLOADS = DATA / "uploads"
PORT = int(os.environ.get("PORT", "8765"))
PICKER_PX = 3          # picker image pixels per 0.1 m grid cell

NEEDED = {"numpy": "numpy", "scipy": "scipy", "cv2": "opencv-python-headless",
          "matplotlib": "matplotlib", "PIL": "pillow"}


VENV = HERE / ".venv"


def venv_python():
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def ensure_libraries():
    """Use the libraries if this Python has them; otherwise install them into a
    private folder (.venv) here, so nothing else on the computer is touched."""
    missing = []
    for mod, pkg in NEEDED.items():
        try:
            importlib.import_module(mod)
        except ImportError:
            missing.append(pkg)
    if not missing:
        return
    if Path(sys.prefix).resolve() == VENV.resolve():
        print("Installing", ", ".join(missing), "(first run only, takes a minute or two) ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])
        importlib.invalidate_caches()
        return
    if not venv_python().exists():
        import venv
        print("Setting up (first run only) ...")
        venv.create(VENV, with_pip=True)
    try:
        sys.exit(subprocess.call([str(venv_python()), str(Path(__file__).resolve()), *sys.argv[1:]]))
    except KeyboardInterrupt:
        sys.exit(0)


# ---------------------------------------------------------------- greens

def safe_name(s):
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", s).strip("_")
    return s[:60] or "green"


def green_dirs():
    """All read greens: ones made by this app, plus the examples already in green-sheet-to-3d."""
    out = {}
    for base in (GREEN_EXAMPLES, GREENS):
        if base.exists():
            for d in sorted(base.iterdir()):
                if (d / "elevation.npy").exists() and (d / "green_mask.npy").exists():
                    out[d.name] = d
    return out


def make_picker(gdir):
    """Top-down shaded picture of the grid with known scale, for clicking a pin."""
    import numpy as np
    from PIL import Image

    z = np.load(gdir / "elevation.npy")
    mask = np.load(gdir / "green_mask.npy")
    meta = json.loads((gdir / "meta.json").read_text()) if (gdir / "meta.json").exists() else {}
    s = meta.get("spacing_m", 0.10)
    gy, gx = np.gradient(z, s)
    shade = np.clip(0.75 + (-gx * 0.7 + gy * 0.7) * 6, 0.35, 1.15)  # light from top-left
    zg = z[mask] if mask.any() else z.ravel()
    t = np.clip((z - zg.min()) / max(np.ptp(zg), 1e-6), 0, 1)
    green = np.stack([60 + 70 * t, 130 + 80 * t, 60 + 50 * t], -1)
    rough = np.stack([205 + 0 * t, 210 + 0 * t, 198 + 0 * t], -1)
    rgb = np.where(mask[..., None], green * shade[..., None], rough * (0.85 + 0.15 * shade[..., None]))
    # dark outline of the green
    edge = mask & ~(np.roll(mask, 1, 0) & np.roll(mask, -1, 0) & np.roll(mask, 1, 1) & np.roll(mask, -1, 1))
    rgb[edge] = (25, 60, 25)
    img = Image.fromarray(np.clip(rgb[::-1], 0, 255).astype("uint8"))   # row 0 = bottom
    img = img.resize((z.shape[1] * PICKER_PX, z.shape[0] * PICKER_PX), Image.NEAREST)
    img.save(gdir / "picker.png")
    rr, cc = np.nonzero(mask) if mask.any() else (np.array([0, z.shape[0] - 1]), np.array([0, z.shape[1] - 1]))
    return dict(spacing=s, rows=int(z.shape[0]), cols=int(z.shape[1]), px_per_cell=PICKER_PX,
                green_left_m=round(cc.min() * s, 3), green_right_m=round(cc.max() * s, 3),
                green_front_m=round(rr.min() * s, 3), green_back_m=round(rr.max() * s, 3))


def green_info(name):
    gdir = green_dirs().get(name)
    if gdir is None:
        return None
    info_path = gdir / "picker.json"
    if not (gdir / "picker.png").exists() or not info_path.exists():
        info_path.write_text(json.dumps(make_picker(gdir)))
    info = json.loads(info_path.read_text())
    info["name"] = name
    info["has_review"] = (gdir / "review.png").exists()
    return info


def on_green(name, x, y):
    import numpy as np
    gdir = green_dirs()[name]
    mask = np.load(gdir / "green_mask.npy")
    s = json.loads((gdir / "picker.json").read_text())["spacing"]
    r, c = int(round(y / s)), int(round(x / s))
    return 0 <= r < mask.shape[0] and 0 <= c < mask.shape[1] and bool(mask[r, c])


# ---------------------------------------------------------------- jobs

JOBS = {}


FAILED = {
    "read": "Couldn't read this green sheet. A sharp, straight-on screenshot or scan works best.",
    "map": "Couldn't make the putt map for this pin. Try a pin a little further from the edge of the green.",
}


def run_job(kind, cmd, cwd, done, cleanup=None):
    jid = uuid.uuid4().hex[:10]
    job = JOBS[jid] = dict(id=jid, kind=kind, state="running", log="", started=time.time(), result=None,
                           error=None)

    def failed():
        job["state"] = "failed"
        msgs = [ln.split("SHEET ERROR:", 1)[1].strip() for ln in job["log"].splitlines() if "SHEET ERROR:" in ln]
        job["error"] = msgs[-1] if msgs else FAILED[kind]
        if cleanup:
            cleanup()

    def work():
        try:
            p = subprocess.Popen(cmd, cwd=cwd or tempfile.gettempdir(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in p.stdout:
                job["log"] += line
            p.wait()
            if p.returncode != 0:
                return failed()
            job["result"] = done()
            job["state"] = "done"
        except Exception as e:  # noqa: BLE001
            job["log"] += f"\n{type(e).__name__}: {e}"
            failed()
        finally:
            job["seconds"] = round(time.time() - job["started"])

    threading.Thread(target=work, daemon=True).start()
    return jid


def start_read(filename, body, params):
    name = safe_name(params.get("name") or Path(filename).stem)
    if name in green_dirs():
        name = f"{name}_{time.strftime('%m%d_%H%M%S')}"
    UPLOADS.mkdir(parents=True, exist_ok=True)
    ext = Path(filename).suffix.lower() if Path(filename).suffix.lower() in (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp") else ".png"
    photo = UPLOADS / f"{name}{ext}"
    photo.write_bytes(body)
    out = GREENS / name
    cmd = [sys.executable, str(SHEET_READER), str(photo), "--out", str(out)]
    if params.get("corners"):
        cmd += ["--corners", params["corners"]]
    if params.get("grid_yards"):
        cmd += ["--grid-yards", str(float(params["grid_yards"]))]
    return run_job("read", cmd, None, lambda: green_info(name),
                   cleanup=lambda: shutil.rmtree(out, ignore_errors=True))


def start_map(p):
    name = p["green"]
    gdir = green_dirs()[name]
    x, y = float(p["x"]), float(p["y"])
    stimp = float(p.get("stimp") or 11)
    radius = float(p.get("radius_ft") or 10)
    spacing = float(p.get("spacing_ft") or 1)
    tag = f"stimp{stimp:g}_pin{x:.1f}_{y:.1f}_{time.strftime('%H%M%S')}"
    out = MAPS / name / tag
    cmd = [sys.executable, str(PUTT_TOOL), str(gdir), "--out", str(out), "--pin", f"{x:.3f},{y:.3f}",
           "--stimp", f"{stimp:g}", "--radius-ft", f"{radius:g}", "--spacing-ft", f"{spacing:g}"]

    def done():
        rel = out.relative_to(DATA).as_posix()
        summary = json.loads((out / "putt_map.json").read_text())
        return dict(folder=rel, files={k: f"/data/{rel}/{k}" for k in
                                       ("putt_map.png", "putt_map_zoom.png", "putt_map.csv")},
                    summary=summary)
    return run_job("map", cmd, None, done)


# ---------------------------------------------------------------- web server

TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".csv": "text/csv",
         ".json": "application/json", ".html": "text/html; charset=utf-8", ".obj": "text/plain"}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, download=False):
        path = path.resolve()
        if not path.is_file():
            return self.send(404, {"error": "not found"})
        extra = {"Content-Disposition": f'attachment; filename="{path.name}"'} if download else None
        self.send(200, path.read_bytes(), TYPES.get(path.suffix.lower(), "application/octet-stream"), extra)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        parts = [unquote(p) for p in u.path.strip("/").split("/") if p]
        try:
            if not parts:
                return self.send_file(HERE / "index.html")
            if parts == ["api", "greens"]:
                return self.send(200, sorted(green_dirs()))
            if parts[:2] == ["api", "green"] and len(parts) == 3:
                info = green_info(parts[2])
                return self.send(200, info) if info else self.send(404, {"error": "no such green"})
            if parts[0] == "green" and len(parts) == 3:       # /green/<name>/<file>
                gdir = green_dirs().get(parts[1])
                if gdir and parts[2] in ("picker.png", "review.png", "relief.png"):
                    return self.send_file(gdir / parts[2])
                return self.send(404, {"error": "not found"})
            if parts[:2] == ["api", "job"] and len(parts) == 3:
                job = JOBS.get(parts[2])
                if not job:
                    return self.send(404, {"error": "no such job"})
                return self.send(200, dict(job, elapsed=round(time.time() - job["started"]),
                                           log=job["log"][-3000:]))
            if parts[0] == "data":
                target = (DATA / Path(*parts[1:])).resolve()
                if DATA.resolve() in target.parents:
                    return self.send_file(target, download=q.get("download") == "1")
            return self.send(404, {"error": "not found"})
        except Exception as e:  # noqa: BLE001
            return self.send(500, {"error": f"{type(e).__name__}: {e}"})

    def do_POST(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n)
        try:
            if u.path == "/api/read":
                if not body:
                    return self.send(400, {"error": "no photo"})
                return self.send(200, {"job": start_read(q.get("filename", "green.png"), body, q)})
            if u.path == "/api/map":
                p = json.loads(body or b"{}")
                if p.get("green") not in green_dirs():
                    return self.send(400, {"error": "Pick a green first."})
                green_info(p["green"])
                if not on_green(p["green"], float(p["x"]), float(p["y"])):
                    return self.send(400, {"error": "That pin is off the green. Click inside the dark outline."})
                return self.send(200, {"job": start_map(p)})
            return self.send(404, {"error": "not found"})
        except Exception as e:  # noqa: BLE001
            return self.send(500, {"error": f"{type(e).__name__}: {e}"})


def main():
    for tool in (GREEN_TOOL, PUTT_TOOL):
        if not tool.exists():
            sys.exit(f"Can't find {tool}. Keep putt-map-app next to green-sheet-to-3d and putting-physics.")
    ensure_libraries()
    for d in (GREENS, MAPS, UPLOADS):
        d.mkdir(parents=True, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}"
    print(f"Putt map app running at {url}  (Ctrl+C to stop)")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
