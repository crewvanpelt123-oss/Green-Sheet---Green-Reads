#!/usr/bin/env python3
"""Read any supported green sheet into an elevation grid.

    python3 read_sheet.py sheet.png --out data/greens/name [--corners ...] [--grid-yards 1]

StrackaLine sheets (stacked slope-band and elevation-colour drawings) go to
strackaline.py; everything else goes to green-sheet-to-3d/green3d.py
(ProGreenBook-style arrows with slope numbers). When a sheet can't be read,
the last line printed is "SHEET ERROR: <plain-English reason>".
"""

import argparse
import contextlib
import io
import json
import os
import sys
import traceback

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
GREEN_TOOLS = os.path.join(os.path.dirname(HERE), "green-sheet-to-3d")
sys.path.insert(0, HERE)
sys.path.insert(0, GREEN_TOOLS)

GENERIC = ("Couldn't read this green sheet. The app reads two kinds: sheets with slope arrows and "
           "slope numbers on a yard grid (like ProGreenBook), and StrackaLine sheets with coloured "
           "slope bands and a Low-High elevation bar. A sharp, straight-on screenshot or scan works best.")


def fail(msg):
    print("SHEET ERROR:", msg)
    sys.exit(2)


def check_output(out):
    try:
        z = np.load(os.path.join(out, "elevation.npy"))
        m = np.load(os.path.join(out, "green_mask.npy"))
    except Exception:  # noqa: BLE001
        fail(GENERIC)
    if not np.isfinite(z).all() or m.sum() < 50:
        fail(GENERIC)
    gy, gx = np.gradient(z, 0.10)
    slope = np.hypot(gx, gy)[m] * 100
    if np.median(slope) > 25:
        fail("The green came out far too steep, so the sheet was probably misread. " + GENERIC)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image")
    ap.add_argument("--out", required=True)
    ap.add_argument("--corners")
    ap.add_argument("--grid-yards", type=float, default=1.0)
    a = ap.parse_args()

    import strackaline
    if strackaline.is_strackaline(a.image):
        print("StrackaLine sheet: reading the elevation colours and slope bands")
        try:
            meta = strackaline.read(a.image, a.out, grid_yards=a.grid_yards)
        except strackaline.SheetError as e:
            fail(str(e))
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            fail(GENERIC)
        print(json.dumps({k: meta[k] for k in ("size_m", "green_height_range_m", "green_slope_pct")}))
    else:
        print("Arrow-and-number sheet: reading the arrows")
        import green3d
        argv = [a.image, "--out", a.out, "--grid-yards", str(a.grid_yards)]
        if a.corners:
            argv += ["--corners", a.corners]
        buf = io.StringIO()
        try:
            with contextlib.redirect_stderr(buf), np.errstate(all="ignore"):
                green3d.main(argv)
        except SystemExit as e:
            if e.code:
                print(buf.getvalue())
                fail(GENERIC)
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            fail(GENERIC)
    check_output(a.out)
    print("done")


if __name__ == "__main__":
    main()
