#!/usr/bin/env python3
"""Read a StrackaLine green sheet into the same elevation grid green3d.py writes.

    python3 strackaline.py sheet.png --out data/greens/southern_hills_18

A StrackaLine sheet stacks up to three drawings of the same green:
  1. slope numbers and small coloured arrows,
  2. slope-% colour bands (grey 0-1 ... magenta 6+) with white arrows,
  3. green elevation colours (blue = low, green = high) with dark arrows,
     and a "Low ... High" colour bar underneath.

The elevation drawing gives the shape of the green directly: each pixel's
colour is looked up on the Low-High bar to get a relative height. That
height is scaled to metres so its slope matches the slope-% bands (only the
bands below 6 %, since 6-7 up to 9+ share one magenta). The grid scale comes
from the 1-yard grid lines.

Outputs (same names and format as green-sheet-to-3d/green3d.py):
elevation.npy/.csv (metres, 0.10 m, row 0 = bottom of the sheet), green_mask.npy,
mesh.obj, meta.json, review.png, relief.png.

`is_strackaline(path)` tells the app which reader to use.
"""

import argparse
import json
import os
import sys

import cv2
import numpy as np

YARD_M = 0.9144
GREEN_TOOLS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "green-sheet-to-3d")


class SheetError(Exception):
    """A plain-English reason the sheet couldn't be read."""


# ---------------------------------------------------------------- image helpers

def load(path):
    im = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if im is None:                      # webp/heic etc. that this OpenCV can't open
        try:
            from PIL import Image
            im = cv2.cvtColor(np.array(Image.open(path).convert("RGB")), cv2.COLOR_RGB2BGR)
        except Exception as e:  # noqa: BLE001
            raise SheetError(f"Couldn't open the image file ({e}).")
    return im


def chroma(im):
    f = im.astype(np.float32)
    return f.max(2) - f.min(2)


def colour_bars(im):
    """Thin horizontal colour bars spanning most of the width (legend, Low-High bar)."""
    H, W = im.shape[:2]
    rowfrac = (chroma(im) > 35).mean(1)
    bars, y = [], 0
    while y < H:
        if rowfrac[y] > 0.6:
            y0 = y
            while y < H and rowfrac[y] > 0.6:
                y += 1
            above = rowfrac[max(0, y0 - 4)]
            below = rowfrac[min(H - 1, y + 3)]
            if y - y0 <= 20 and above < 0.3 and below < 0.3:   # a thin bar, not a row of a drawing
                bars.append((y0, y))
        y += 1
    out = []
    for y0, y1 in bars:
        mid = (y0 + y1) // 2
        row = np.median(im[max(y0, mid - 1):min(y1, mid + 2)], axis=0)       # W x 3
        # longest stretch of non-white (the 0-1 legend swatch is grey, so not chroma)
        nonwhite = row.min(1) < 225
        x0 = x1 = best0 = best1 = -1
        for x in range(W + 1):
            if x < W and nonwhite[x]:
                if x0 < 0 or x - x1 > 3:
                    x0 = x
                x1 = x
            if x1 - x0 > best1 - best0:
                best0, best1 = x0, x1
        x0, x1 = best0, best1
        if x1 - x0 < 0.5 * W:
            continue
        x0, x1 = x0 + 3, x1 - 3                       # drop anti-aliased ends
        seg = row[x0:x1 + 1].astype(np.float32)
        # a ramp changes smoothly; a legend has flat runs with jumps between them
        steps = np.abs(np.diff(seg, axis=0)).sum(1)
        out.append(dict(y0=y0, y1=y1, x0=int(x0), x1=int(x1), colours=seg,
                        jumpy=float((steps > 40).sum()), smooth=float(np.median(steps))))
    return out


def find_ramp(bars):
    """The Low-High elevation bar: colour changes gradually from blue to green."""
    best = None
    for b in bars:
        c = b["colours"]
        # strip any legend-like bar; the ramp has few big jumps and runs blue -> green
        left, right = c[: len(c) // 10].mean(0), c[-len(c) // 10:].mean(0)   # BGR
        bluish_left = left[0] > left[2] + 30
        greenish_right = right[1] > right[2] + 30 and right[1] > right[0] + 30
        if b["jumpy"] <= 6 and bluish_left and greenish_right:
            if best is None or b["y0"] > best["y0"]:
                best = b
    return best


def find_legend(bars):
    """The slope-% legend: flat colour runs (grey, light blue, blue, greens, red, orange, magenta)."""
    for b in bars:
        if b["jumpy"] > 6:
            return b
    return None


def legend_bins(legend):
    """Ten equal segments, labelled 0-1 ... 9+. Returns [(lo_pct, hi_pct, colour)] with
    segments of the same colour merged (on StrackaLine 6-7 up to 9+ are one magenta)."""
    c = legend["colours"]
    n = 10
    w = len(c) / n
    segs = []
    for i in range(n):
        a, b = int(i * w + w * 0.25), int((i + 1) * w - w * 0.25)
        segs.append([i, i + 1 if i < n - 1 else np.inf, np.median(c[a:b], 0)])
    merged = [segs[0]]
    for s in segs[1:]:
        if np.linalg.norm(s[2] - merged[-1][2]) < 35:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    return [(float(lo), float(hi), col) for lo, hi, col in merged]


def big_fills(im):
    """Large solid-coloured regions (the coloured green drawings)."""
    H, W = im.shape[:2]
    fill = (chroma(im) > 35).astype(np.uint8)
    fill = cv2.morphologyEx(fill, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(fill, 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a > 0.02 * H * W and w < 0.95 * W:
            m = lab == i
            m = fill_holes(m)
            out.append(dict(mask=m, bbox=(int(x), int(y), int(w), int(h))))
    return out


def fill_holes(m):
    m = m.astype(np.uint8)
    ff = m.copy()
    h, w = m.shape
    cv2.floodFill(ff, np.zeros((h + 2, w + 2), np.uint8), (0, 0), 1)
    return (m > 0) | (ff == 0)


def nearest(colours, palette):
    """Index of and distance to the nearest palette colour for each pixel colour."""
    d = np.linalg.norm(colours[:, None, :].astype(np.float32) - palette[None].astype(np.float32), axis=2)
    i = d.argmin(1)
    return i, d[np.arange(len(i)), i]


def grid_pitch(gray, background):
    """Pixels between the thin grid lines: autocorrelation of thin-line responses,
    counted only on plain background (not the coloured drawings or arrows)."""
    blur = cv2.GaussianBlur(gray.astype(np.float32), (0, 0), 1.5)
    line = np.clip(blur - gray.astype(np.float32), 0, 60) * background
    best = []
    for axis in (0, 1):
        p = line.sum(axis) / np.maximum(background.sum(axis), 1)
        p = p - p.mean()
        ac = np.correlate(p, p, "full")[len(p) - 1:]
        lo, hi = 6, min(80, len(ac) - 2)
        # the first strong peak is the grid; later peaks are its multiples
        seg = ac[lo:hi]
        peaks = [i for i in range(1, len(seg) - 1) if seg[i] >= seg[i - 1] and seg[i] >= seg[i + 1]]
        top = max(seg[i] for i in peaks) if peaks else seg.max()
        k = lo + next((i for i in peaks if seg[i] >= 0.6 * top), int(np.argmax(seg)))
        a, b, c = ac[k - 1], ac[k], ac[k + 1]
        best.append(k + 0.5 * (a - c) / (a - 2 * b + c + 1e-9))
    return float(np.mean(best)), best


def smooth_fill(values, valid, sigma):
    """Gaussian normalised convolution: fills gaps (arrows, grid lines) and smooths."""
    v = np.where(valid, values, 0).astype(np.float32)
    w = valid.astype(np.float32)
    num = cv2.GaussianBlur(v, (0, 0), sigma)
    den = cv2.GaussianBlur(w, (0, 0), sigma)
    return num / np.maximum(den, 1e-6), den


def extend_outside(z, mask, iters=400):
    """Carry the green's heights smoothly onto the fringe (harmonic fill)."""
    z = np.where(mask, z, np.nan)
    known = mask.copy()
    out = np.where(known, z, np.nanmean(z[mask]))
    for _ in range(iters):
        avg = 0.25 * (np.roll(out, 1, 0) + np.roll(out, -1, 0) + np.roll(out, 1, 1) + np.roll(out, -1, 1))
        out = np.where(known, out, avg)
    return out


# ---------------------------------------------------------------- detection

def is_strackaline(path):
    try:
        im = load(path)
    except SheetError:
        return False
    return find_ramp(colour_bars(im)) is not None and len(big_fills(im)) >= 1


# ---------------------------------------------------------------- reader

def read(path, out, spacing=0.10, grid_yards=1.0):
    im = load(path)
    H, W = im.shape[:2]
    bars = colour_bars(im)
    ramp = find_ramp(bars)
    if ramp is None:
        raise SheetError("This doesn't look like a StrackaLine sheet: there's no Low-High green "
                         "elevation colour bar.")
    legend = find_legend(bars)
    fills = big_fills(im)

    ramp_cols = ramp["colours"]
    ramp_pal = ramp_cols[:: max(1, len(ramp_cols) // 120)]
    ramp_t = np.linspace(0, 1, len(ramp_pal))

    # which fill is the elevation drawing: the one whose colours sit on the ramp
    def ramp_share(f):
        px = im[f["mask"]][::7]
        _, d = nearest(px, ramp_pal)
        return float((d < 30).mean())
    for f in fills:
        f["ramp_share"] = ramp_share(f)
    elev = max(fills, key=lambda f: f["ramp_share"], default=None)
    if elev is None or elev["ramp_share"] < 0.4:
        raise SheetError("Couldn't find the coloured elevation drawing of the green on this sheet.")

    slope_panel, bins = None, None
    if legend is not None:
        bins = legend_bins(legend)
        pal = np.array([b[2] for b in bins])
        cands = [f for f in fills if f is not elev]
        if cands:
            def legend_share(f):
                _, d = nearest(im[f["mask"]][::7], pal)
                return float((d < 40).mean())
            slope_panel = max(cands, key=legend_share)
            if legend_share(slope_panel) < 0.15:
                slope_panel = None
    if slope_panel is None:
        raise SheetError("Couldn't find the slope-% colour drawing and its legend, which set the "
                         "steepness of the green.")

    # ---- scale from the 1-yard grid, measured on the elevation drawing's half of the page
    ex, ey, ew, eh = elev["bbox"]
    pad = int(0.15 * max(ew, eh))
    y0, y1 = max(0, ey - pad), min(H, ey + eh + pad)
    gray = cv2.cvtColor(im[y0:y1], cv2.COLOR_BGR2GRAY)
    drawn = np.zeros((H, W), np.uint8)
    for f in fills:
        drawn |= f["mask"].astype(np.uint8)
    drawn |= (chroma(im) > 25).astype(np.uint8)
    background = cv2.dilate(drawn, np.ones((7, 7), np.uint8))[y0:y1] == 0
    pitch, pitches = grid_pitch(gray, background.astype(np.float32))
    if not (5 <= pitch <= 80) or abs(pitches[0] - pitches[1]) > 0.1 * pitch:
        raise SheetError("Couldn't measure the 1-yard grid on this sheet. A sharper image may help.")
    m_per_px = grid_yards * YARD_M / pitch

    # ---- relative height from elevation colours
    emask = elev["mask"]
    core = cv2.erode(emask.astype(np.uint8), np.ones((5, 5), np.uint8)) > 0
    ys, xs = np.nonzero(emask)
    idx, d = nearest(im[ys, xs], ramp_pal)
    t = np.zeros((H, W), np.float32)
    ok = np.zeros((H, W), bool)
    t[ys, xs] = ramp_t[idx]
    ok[ys, xs] = d < 22                  # drops the dark arrows and grid lines over the colour
    ok &= core
    if ok.sum() < 0.3 * emask.sum():
        raise SheetError("The elevation colours on the green didn't match the Low-High bar.")
    sig = max(1.5, 0.35 * pitch)         # about a third of a yard
    ts, den = smooth_fill(t, ok, sig)
    ts = np.where(emask, ts, np.nan)

    # ---- slope bands, mapped from the slope drawing onto the elevation drawing
    sx, sy, sw, sh = slope_panel["bbox"]
    smask = slope_panel["mask"]
    ys2, xs2 = np.nonzero(smask)
    pal = np.array([b[2] for b in bins])
    bi, bd = nearest(im[ys2, xs2], pal)
    good = (bd < 40) & (chroma(im[ys2, xs2][None])[0] > 60)
    band = np.full((H, W), -1, int)
    band[ys2[good], xs2[good]] = bi[good]
    # map elevation-drawing pixel -> slope-drawing pixel by matching the outlines' boxes
    fx, fy = sw / ew, sh / eh

    # band label around each slope-drawing pixel (majority within ~half a yard)
    r = max(2, int(round(0.4 * pitch)))
    dens = np.stack([cv2.boxFilter((band == k).astype(np.float32), -1, (2 * r + 1, 2 * r + 1))
                     for k in range(len(bins))])

    # downhill direction from the elevation colours, smoothed over about a yard
    sig_dir = 0.75 * pitch
    tdir, _ = smooth_fill(t, ok, sig_dir)
    gy, gx = np.gradient(tdir, m_per_px)
    gy = -gy                                   # image rows run down the sheet; y_m runs up
    gmag = np.hypot(gx, gy)                    # ramp units per metre

    # sample points every half yard inside the green
    step = max(2, int(round(pitch / 2)))
    inner = cv2.erode(emask.astype(np.uint8), np.ones((int(pitch) | 1, int(pitch) | 1), np.uint8)) > 0
    vv, uu = np.mgrid[ey:ey + eh:step, ex:ex + ew:step]
    vv, uu = vv.ravel(), uu.ravel()
    keep = inner[vv, uu] & (gmag[vv, uu] > 0)
    vv, uu = vv[keep], uu[keep]
    su = np.clip(np.round(sx + (uu - ex) * fx).astype(int), 0, W - 1)
    sv = np.clip(np.round(sy + (vv - ey) * fy).astype(int), 0, H - 1)
    dk = dens[:, sv, su]
    kbest = dk.argmax(0)
    known = dk.max(0) > 0.15
    lo = np.array([bins[k][0] for k in kbest])
    hi = np.array([bins[k][1] for k in kbest])
    bounded = known & np.isfinite(hi)
    open_top = known & ~np.isfinite(hi)
    g_here = gmag[vv, uu]

    # metres of height per ramp unit, from the bands that have both ends (2-3 ... 5-6)
    if bounded.sum() < 20:
        raise SheetError("Not enough of the green is in the measurable slope bands to set its steepness.")
    mid = (lo + np.where(np.isfinite(hi), hi, lo + 1)) / 2
    scale = float(np.median(mid[bounded] / 100 / g_here[bounded]))
    # The Low-High colours aren't evenly spaced in height, so the metres per colour step
    # is measured separately along the colour bar (in steps of 0.05) and interpolated.
    tt = tdir[vv, uu]
    rat = mid / 100 / g_here
    tc, rc = [], []
    for q0 in np.arange(0, 1, 0.05):
        sel = bounded & (tt >= q0) & (tt < q0 + 0.05)
        if sel.sum() >= 15:
            tc.append(q0 + 0.025)
            rc.append(float(np.median(rat[sel])))
    local_scale = np.interp(tt, tc, rc) if len(tc) >= 2 else np.full(len(tt), scale)
    pct = np.where(bounded, mid, np.nan)
    # 6+ (one magenta for 6-7 up to 9+): the elevation colours say how much more than 6
    pct = np.where(open_top, np.maximum(lo + 0.5, local_scale * g_here * 100), pct)
    # no band read here (white arrow, label): use the elevation colours alone
    pct = np.where(~known, local_scale * g_here * 100, pct)
    dir_deg = np.degrees(np.arctan2(-gy[vv, uu], -gx[vv, uu])) % 360

    # ---- output grid (row 0 = bottom): the drawing plus 2 yards around it
    marg = int(round(2 * pitch))
    gx0, gx1 = max(0, ex - marg), min(W - 1, ex + ew + marg)
    gy0, gy1 = max(0, ey - marg), min(H - 1, ey + eh + marg)
    width_m, height_m = (gx1 - gx0) * m_per_px, (gy1 - gy0) * m_per_px
    tab = dict(x_m=(uu - gx0) * m_per_px, y_m=(gy1 - vv) * m_per_px, dir_deg=dir_deg, slope_pct=pct,
               source=np.where(bounded, "number:band", np.where(open_top, "colour:6+", "colour:elevation")))
    sys.path.insert(0, str(GREEN_TOOLS))
    import surface as su
    rec = su.reconstruct(tab, spacing=spacing, lam=0.05, extent=(0.0, 0.0, width_m, height_m))
    z = rec["z"]
    ny, nx = z.shape
    X = gx0 + (np.arange(nx) * spacing) / m_per_px
    Y = gy1 - (np.arange(ny) * spacing) / m_per_px
    mapx, mapy = np.meshgrid(X.astype(np.float32), Y.astype(np.float32))
    gmask = cv2.remap(emask.astype(np.uint8), mapx, mapy, cv2.INTER_NEAREST) > 0
    if gmask.sum() < 50:
        raise SheetError("The green came out too small to use.")
    z = z - z[gmask].mean()
    if not np.isfinite(z).all():
        raise SheetError("The rebuilt green had gaps in it.")

    check = []
    for k, (blo, bhi, _) in enumerate(bins):
        sel = known & (kbest == k)
        if sel.sum() >= 5:
            check.append(dict(band=f"{blo:g}-{bhi:g}" if np.isfinite(bhi) else f"{blo:g}+",
                              points=int(sel.sum()),
                              rebuilt_median_pct=round(float(np.median(rec["fit_slope"][sel])), 2)))

    os.makedirs(out, exist_ok=True)
    np.save(os.path.join(out, "elevation.npy"), z)
    np.savetxt(os.path.join(out, "elevation.csv"), z, delimiter=",", fmt="%.5f")
    np.save(os.path.join(out, "green_mask.npy"), gmask)
    write_obj(os.path.join(out, "mesh.obj"), z, spacing)

    gyz, gxz = np.gradient(z, spacing)
    sl = np.hypot(gxz, gyz)[gmask] * 100
    meta = dict(
        source_image=os.path.basename(str(path)), sheet_type="StrackaLine",
        grid_format="heights in metres; row 0 = bottom edge of the sheet; columns run left to right; "
                    "origin (0, 0) at the bottom-left cell; even spacing",
        spacing_m=spacing, rows=int(ny), cols=int(nx),
        size_m=[round((nx - 1) * spacing, 2), round((ny - 1) * spacing, 2)],
        sheet_px_per_grid_square=round(pitch, 2), grid_square_yards=grid_yards,
        height_scale_m_per_ramp=round(scale, 4), slope_points=int(len(pct)),
        height_range_m=round(float(np.ptp(z)), 3),
        green_height_range_m=round(float(np.ptp(z[gmask])), 3),
        green_slope_pct=dict(median=round(float(np.median(sl)), 2), max=round(float(sl.max()), 2)),
        slope_band_check=check,
    )
    with open(os.path.join(out, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)
    draw_review(im, elev, slope_panel, os.path.join(out, "review.png"))
    draw_relief(z, gmask, spacing, check, os.path.join(out, "relief.png"))
    return meta


def write_obj(path, z, h):
    ny, nx = z.shape
    with open(path, "w") as f:
        f.write("# green surface, metres, Z up\n")
        for i in range(ny):
            for j in range(nx):
                f.write(f"v {j * h:.3f} {i * h:.3f} {z[i, j]:.4f}\n")
        for i in range(ny - 1):
            for j in range(nx - 1):
                a = i * nx + j + 1
                f.write(f"f {a} {a + 1} {a + nx + 1}\nf {a} {a + nx + 1} {a + nx}\n")


def draw_review(im, elev, slope_panel, path):
    out = im.copy()
    for f, col in ((elev, (255, 0, 255)), (slope_panel, (255, 0, 255))):
        cs, _ = cv2.findContours(f["mask"].astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cv2.drawContours(out, cs, -1, col, 2)
        x, y, w, h = f["bbox"]
        label = "elevation colours (used for shape)" if f is elev else "slope bands (used for steepness)"
        cv2.putText(out, label, (x, max(12, y - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 0, 120), 1)
    s = 1600 / out.shape[0]
    cv2.imwrite(path, cv2.resize(out, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC if s > 1 else cv2.INTER_AREA))


def draw_relief(z, gmask, h, check, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LightSource
    ny, nx = z.shape
    ext = (0, (nx - 1) * h, 0, (ny - 1) * h)
    fig, axs = plt.subplots(1, 2, figsize=(13, 7.5))
    zc = z * 100
    rgb = LightSource(azdeg=315, altdeg=35).shade(zc, cmap=plt.cm.terrain, vert_exag=12, dx=h * 100,
                                                    dy=h * 100, blend_mode="soft")
    ax = axs[0]
    ax.imshow(rgb, origin="lower", extent=ext)
    zin = np.where(gmask, zc, np.nan)
    lv = np.arange(np.floor(np.nanmin(zin) / 5) * 5, np.nanmax(zin) + 5, 5.0)
    xs, ys = np.linspace(0, ext[1], nx), np.linspace(0, ext[3], ny)
    ax.contour(xs, ys, zin, levels=lv, colors="k", linewidths=0.4, alpha=0.6)
    ax.contour(xs, ys, gmask.astype(float), levels=[0.5], colors="g", linewidths=1.5)
    ax.set_title("Rebuilt green (5 cm contours), fall %.2f m" % np.ptp(z[gmask]))
    ax.set_aspect("equal")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m), 0 = bottom of sheet")
    ax = axs[1]
    labels = [c["band"] for c in check]
    vals = [c["rebuilt_median_pct"] for c in check]
    ax.bar(labels, vals, color="#4a8a4a")
    for i, c in enumerate(check):
        b = c["band"]
        if "+" in b:
            ax.axhline(float(b[:-1]), xmin=i / len(check), xmax=(i + 1) / len(check), color="r")
        else:
            lo, hi = (float(v) for v in b.split("-"))
            ax.fill_between([i - 0.4, i + 0.4], lo, hi, color="r", alpha=0.2)
    ax.set_xlabel("slope band on the sheet (%)")
    ax.set_ylabel("median slope of rebuilt green there (%)")
    ax.set_title("Check: bars should sit in the red ranges")
    fig.tight_layout()
    fig.savefig(path, dpi=110)
    plt.close(fig)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("image")
    ap.add_argument("--out", required=True)
    ap.add_argument("--grid-yards", type=float, default=1.0)
    ap.add_argument("--spacing", type=float, default=0.10)
    a = ap.parse_args(argv)
    try:
        meta = read(a.image, a.out, spacing=a.spacing, grid_yards=a.grid_yards)
    except SheetError as e:
        print("SHEET ERROR:", e)
        sys.exit(2)
    print(json.dumps({k: meta[k] for k in ("size_m", "green_height_range_m", "green_slope_pct",
                                          "slope_band_check")}, indent=1))


if __name__ == "__main__":
    main()
