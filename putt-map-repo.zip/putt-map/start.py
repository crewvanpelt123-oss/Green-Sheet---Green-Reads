#!/usr/bin/env python3
"""Start the Putt Map app:  python3 start.py  (run in this folder)."""
import os
import runpy
import sys

app = os.path.join(os.path.dirname(os.path.abspath(__file__)), "putt-map-app", "start.py")
sys.argv[0] = app
runpy.run_path(app, run_name="__main__")
